package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.model.SleepLog
import com.example.ui.LifeTrackViewModel
import com.example.util.LifeTrackStrings

@Composable
fun SleepScreen(
  viewModel: LifeTrackViewModel,
  modifier: Modifier = Modifier
) {
  val lang by viewModel.language.collectAsState()
  val sleepLogs by viewModel.sleepLogs.collectAsState()
  val latestSleep by viewModel.latestSleep.collectAsState()
  val userProfile by viewModel.userProfile.collectAsState()

  val targetSleepHours = userProfile?.sleepTargetHours ?: 8.0
  var showAddDialog by remember { mutableStateOf(false) }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    floatingActionButton = {
      FloatingActionButton(
        onClick = { showAddDialog = true },
        containerColor = Color(0xFF7C3AED),
        contentColor = Color.White,
        modifier = Modifier.testTag("add_sleep_fab")
      ) {
        Icon(Icons.Default.Add, contentDescription = "Log Sleep")
      }
    }
  ) { padding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      item {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = LifeTrackStrings.get("sleep", lang),
          style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onBackground
        )
      }

      // Latest Sleep Hero Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(24.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(20.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = "Last Night's Sleep",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                val durationHrs = latestSleep?.let { it.durationMinutes / 60 } ?: 7
                val durationMins = latestSleep?.let { it.durationMinutes % 60 } ?: 45
                Text(
                  text = "${durationHrs}h ${durationMins}m",
                  style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                  color = Color(0xFF7C3AED)
                )
              }
              Box(
                modifier = Modifier
                  .size(48.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFEDE9FE)),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.Bedtime, contentDescription = null, tint = Color(0xFF7C3AED), modifier = Modifier.size(28.dp))
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Times Row
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                .padding(12.dp),
              horizontalArrangement = Arrangement.SpaceAround
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Bedtime, contentDescription = null, tint = Color(0xFF7C3AED), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "Bed: ${latestSleep?.sleepTime ?: "11:00 PM"}", style = MaterialTheme.typography.bodySmall)
              }
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.WbSunny, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "Wake: ${latestSleep?.wakeTime ?: "06:45 AM"}", style = MaterialTheme.typography.bodySmall)
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Sleep Goal progress
            val actualHours = (latestSleep?.durationMinutes ?: 465) / 60.0
            val sleepProgress = (actualHours / targetSleepHours).toFloat().coerceIn(0f, 1f)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text(text = "Goal: ${targetSleepHours}h", style = MaterialTheme.typography.labelSmall)
              Text(text = "${(sleepProgress * 100).toInt()}% achieved", style = MaterialTheme.typography.labelSmall, color = Color(0xFF7C3AED))
            }
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
              progress = { sleepProgress },
              modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
              color = Color(0xFF7C3AED),
              trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Quality Stars
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(text = "Sleep Quality: ", style = MaterialTheme.typography.labelMedium)
              val rating = latestSleep?.qualityRating ?: 4
              for (i in 1..5) {
                Icon(
                  if (i <= rating) Icons.Default.Star else Icons.Default.StarBorder,
                  contentDescription = null,
                  tint = if (i <= rating) Color(0xFFF59E0B) else Color.Gray,
                  modifier = Modifier.size(18.dp)
                )
              }
            }
          }
        }
      }

      // History of Sleep Records
      item {
        Text(
          text = "Sleep History",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )
      }

      if (sleepLogs.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Text(
                text = "No sleep logs recorded yet.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Spacer(modifier = Modifier.height(10.dp))
              Button(
                onClick = { showAddDialog = true },
                shape = RoundedCornerShape(12.dp)
              ) {
                Text("+ Record Last Night's Sleep")
              }
            }
          }
        }
      } else {
        items(sleepLogs) { log ->
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(text = log.date, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                  text = "${log.durationMinutes / 60}h ${log.durationMinutes % 60}m",
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                  color = Color(0xFF7C3AED)
                )
                Text(
                  text = "${log.sleepTime} - ${log.wakeTime}",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
              Row {
                for (i in 1..log.qualityRating) {
                  Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(16.dp))
                }
              }
            }
          }
        }
      }

      item {
        Spacer(modifier = Modifier.height(80.dp))
      }
    }
  }

  if (showAddDialog) {
    AddSleepDialog(
      lang = lang,
      onDismiss = { showAddDialog = false },
      onSave = { sleep, wake, duration, quality, notes ->
        viewModel.addSleep(sleep, wake, duration, quality, notes)
        showAddDialog = false
      }
    )
  }
}

@Composable
private fun AddSleepDialog(
  lang: String,
  onDismiss: () -> Unit,
  onSave: (sleepTime: String, wakeTime: String, durationMin: Int, quality: Int, notes: String) -> Unit
) {
  var sleepTime by remember { mutableStateOf("11:00 PM") }
  var wakeTime by remember { mutableStateOf("07:00 AM") }
  var durationHours by remember { mutableStateOf("8") }
  var durationMinutesPart by remember { mutableStateOf("0") }
  var qualityRating by remember { mutableIntStateOf(4) }
  var notes by remember { mutableStateOf("") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(24.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 6.dp,
      modifier = Modifier.fillMaxWidth(0.95f)
    ) {
      Column(modifier = Modifier.padding(20.dp)) {
        Text(
          text = "Record Sleep Session",
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
        )
        Spacer(modifier = Modifier.height(14.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = sleepTime,
            onValueChange = { sleepTime = it },
            label = { Text("Bedtime") },
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = wakeTime,
            onValueChange = { wakeTime = it },
            label = { Text("Wake-up Time") },
            modifier = Modifier.weight(1f)
          )
        }
        Spacer(modifier = Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = durationHours,
            onValueChange = { durationHours = it },
            label = { Text("Hours") },
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = durationMinutesPart,
            onValueChange = { durationMinutesPart = it },
            label = { Text("Minutes") },
            modifier = Modifier.weight(1f)
          )
        }
        Spacer(modifier = Modifier.height(12.dp))

        Text(text = "Quality Rating (1-5 Stars)", style = MaterialTheme.typography.labelMedium)
        Spacer(modifier = Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          for (i in 1..5) {
            Icon(
              if (i <= qualityRating) Icons.Default.Star else Icons.Default.StarBorder,
              contentDescription = "$i stars",
              tint = if (i <= qualityRating) Color(0xFFF59E0B) else Color.Gray,
              modifier = Modifier
                .size(32.dp)
                .clickable { qualityRating = i }
            )
          }
        }
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("Notes (e.g. Deep sleep, felt refreshed)") },
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(20.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
          TextButton(onClick = onDismiss) { Text(LifeTrackStrings.get("cancel", lang)) }
          Spacer(modifier = Modifier.width(8.dp))
          Button(
            onClick = {
              val hrs = durationHours.toIntOrNull() ?: 7
              val mins = durationMinutesPart.toIntOrNull() ?: 0
              val totalMin = (hrs * 60) + mins
              onSave(sleepTime, wakeTime, totalMin, qualityRating, notes)
            }
          ) {
            Text(LifeTrackStrings.get("save", lang))
          }
        }
      }
    }
  }
}
