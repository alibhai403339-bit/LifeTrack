package com.example.util

object LifeTrackStrings {
  // Languages
  const val LANG_EN = "en"
  const val LANG_BN = "bn"

  fun get(key: String, lang: String = LANG_EN): String {
    val isBn = lang == LANG_BN
    return when (key) {
      // General Navigation
      "app_name" -> if (isBn) "লাইফট্র্যাক" else "LifeTrack"
      "home" -> if (isBn) "হোম" else "Home"
      "routine" -> if (isBn) "রুটিন" else "Routine"
      "health" -> if (isBn) "স্বাস্থ্য" else "Health"
      "finance" -> if (isBn) "ফাইন্যান্স" else "Finance"
      "profile" -> if (isBn) "প্রোফাইল" else "Profile"
      "meals" -> if (isBn) "খাবার" else "Meals"
      "water" -> if (isBn) "পানি" else "Water"
      "workout" -> if (isBn) "ব্যায়াম" else "Gym / Workout"
      "sleep" -> if (isBn) "ঘুম" else "Sleep"
      "shopping" -> if (isBn) "বাজার তালিকা" else "Shopping"
      "tasks" -> if (isBn) "কাজ ও তাগিদ" else "Tasks"
      "calendar" -> if (isBn) "ইতিহাস" else "History"
      "analytics" -> if (isBn) "পরিসংখ্যান" else "Analytics"

      // Actions
      "add" -> if (isBn) "যোগ করুন" else "Add"
      "save" -> if (isBn) "সংরক্ষণ করুন" else "Save"
      "cancel" -> if (isBn) "বাতিল" else "Cancel"
      "delete" -> if (isBn) "মুছুন" else "Delete"
      "edit" -> if (isBn) "সম্পাদনা" else "Edit"
      "done" -> if (isBn) "সম্পন্ন" else "Done"
      "undo" -> if (isBn) "পূর্বাবস্থায় ফেরান" else "Undo"
      "quick_add" -> if (isBn) "দ্রুত যুক্ত করুন" else "Quick Add"
      "sign_in_google" -> if (isBn) "Google দিয়ে সাইন ইন করুন" else "Sign in with Google"
      "sign_out" -> if (isBn) "সাইন আউট" else "Sign Out"
      "get_started" -> if (isBn) "শুরু করুন" else "Get Started"
      "skip" -> if (isBn) "এড়িয়ে যান" else "Skip"
      "next" -> if (isBn) "পরবর্তী" else "Next"

      // Greetings & Dashboard
      "good_morning" -> if (isBn) "শুভ সকাল" else "Good Morning"
      "good_afternoon" -> if (isBn) "শুভ দুপুর" else "Good Afternoon"
      "good_evening" -> if (isBn) "শুভ সন্ধ্যা" else "Good Evening"
      "welcome_back" -> if (isBn) "স্বাগতম!" else "Welcome Back!"
      "today_progress" -> if (isBn) "আজকের অগ্রগতি" else "Today's Progress"
      "daily_completion" -> if (isBn) "দৈনিক রুটিন সম্পন্ন" else "Daily Routine Completion"
      "today_tasks" -> if (isBn) "আজকের কাজসমূহ" else "Today's Tasks"
      "water_intake" -> if (isBn) "পানি পান" else "Water Intake"
      "sleep_duration" -> if (isBn) "ঘুমের সময়" else "Sleep Duration"
      "daily_balance" -> if (isBn) "আজকের ব্যালেন্স" else "Daily Balance"
      "income" -> if (isBn) "আয়" else "Income"
      "expense" -> if (isBn) "ব্যয়" else "Expense"
      "savings" -> if (isBn) "সঞ্চয়" else "Savings"
      "steps" -> if (isBn) "পদক্ষেপ" else "Steps"

      // Quotes
      "quote_1" -> if (isBn) "ছোট ছোট পদক্ষেপেই বড় পরিবর্তন আসে।" else "Small daily habits lead to monumental achievements."
      "quote_2" -> if (isBn) "সুস্বাস্থ্যই মানুষের সবচেয়ে বড় সম্পদ।" else "Health is the greatest wealth you can nurture today."
      "quote_3" -> if (isBn) "শৃঙ্খলা হলো লক্ষ্য এবং অর্জনের মধ্যবর্তী সেতু।" else "Discipline is the bridge between goals and accomplishment."
      "quote_4" -> if (isBn) "প্রতিটি দিন একটি নতুন শুরু ও সম্ভাবনা।" else "Every sunrise brings a new opportunity to excel."

      // Hydration
      "hydration_target" -> if (isBn) "দৈনিক লক্ষ্য" else "Daily Target"
      "consumed" -> if (isBn) "পান করা হয়েছে" else "Consumed"
      "remaining" -> if (isBn) "বাকি আছে" else "Remaining"
      "add_250" -> if (isBn) "+২৫০ মি.লি." else "+250 ml"
      "add_500" -> if (isBn) "+৫০০ মি.লি." else "+500 ml"
      "add_1000" -> if (isBn) "+১ লিটার" else "+1000 ml"
      "hydration_disclaimer" -> if (isBn) "ব্যক্তিগত প্রয়োজন অনুযায়ী পানির চাহিদা ভিন্ন হতে পারে।" else "Hydration needs vary based on activity and climate."

      // Routines
      "wake_up_time" -> if (isBn) "ঘুম থেকে ওঠার সময়" else "Wake-up Time"
      "bedtime" -> if (isBn) "ঘুমাতে যাওয়ার সময়" else "Bedtime"
      "habits_routines" -> if (isBn) "অভ্যাস ও দৈনন্দিন রুটিন" else "Habits & Daily Routines"
      "completed" -> if (isBn) "সম্পন্ন" else "Completed"
      "pending" -> if (isBn) "চলমান" else "Pending"
      "skipped" -> if (isBn) "বাদ দেওয়া হয়েছে" else "Skipped"

      // Meals & Nutrition
      "breakfast" -> if (isBn) "সকালের নাস্তা" else "Breakfast"
      "lunch" -> if (isBn) "দুপুরের খাবার" else "Lunch"
      "dinner" -> if (isBn) "রাতের খাবার" else "Dinner"
      "snack" -> if (isBn) "হালকা খাবার / স্ন্যাক্স" else "Snack"
      "calories" -> if (isBn) "ক্যালরি" else "Calories"
      "protein" -> if (isBn) "প্রোটিন" else "Protein"
      "carbs" -> if (isBn) "কার্বোহাইড্রেট" else "Carbs"
      "fat" -> if (isBn) "ফ্যাট" else "Fat"
      "nutrition_disclaimer" -> if (isBn) "আনুমানিক পুষ্টিমান কেবল সাধারণ ধারণার জন্য, কোনো চিকিৎসা পরামর্শ নয়।" else "Estimated nutritional values are for personal guidance, not medical diagnosis."

      // Fitness & Gym
      "workout_timer" -> if (isBn) "ব্যায়াম টাইমার" else "Workout Timer"
      "rest_timer" -> if (isBn) "বিশ্রাম টাইমার" else "Rest Timer"
      "sets" -> if (isBn) "সেট" else "Sets"
      "reps" -> if (isBn) "রেপস" else "Reps"
      "weight" -> if (isBn) "ওজন (কেজি)" else "Weight (kg)"
      "duration" -> if (isBn) "সময় (মিনিট)" else "Duration (min)"
      "start" -> if (isBn) "শুরু" else "Start"
      "pause" -> if (isBn) "থামুন" else "Pause"
      "reset" -> if (isBn) "পুনরায়" else "Reset"

      // Health & Wellness
      "bmi_calculator" -> if (isBn) "বিএমআই পরিমাপক" else "BMI Calculator"
      "height" -> if (isBn) "উচ্চতা (সে.মি.)" else "Height (cm)"
      "body_weight" -> if (isBn) "শরীরের ওজন (কেজি)" else "Body Weight (kg)"
      "bmi_disclaimer" -> if (isBn) "বিএমআই কেবল একটি প্রাথমিক নির্দেশক, এটি কোনো রোগ নির্ণয় করে না।" else "BMI is a general screening indicator, not a definitive health diagnosis."
      "mood_tracker" -> if (isBn) "আজকের মেজাজ" else "Today's Mood"
      "energy_level" -> if (isBn) "শক্তির মাত্রা" else "Energy Level"

      // Finance
      "monthly_budget" -> if (isBn) "মাসিক বাজেট" else "Monthly Budget"
      "budget_spent" -> if (isBn) "খরচ হয়েছে" else "Spent"
      "budget_warning" -> if (isBn) "সতর্কতা: আপনার বাজেট প্রায় শেষের পথে!" else "Alert: You have reached 80% or more of your monthly budget!"
      "payment_method" -> if (isBn) "পেমেন্ট মাধ্যম" else "Payment Method"
      "category" -> if (isBn) "ক্যাটেগরি" else "Category"

      // Shopping
      "shopping_list" -> if (isBn) "বাজার ও কেনাকাটার তালিকা" else "Shopping & Grocery List"
      "est_price" -> if (isBn) "আনুমানিক মূল্য" else "Est. Price"
      "actual_price" -> if (isBn) "আসল মূল্য" else "Actual Price"
      "total_estimated" -> if (isBn) "মোট আনুমানিক" else "Total Estimated"
      "total_actual" -> if (isBn) "মোট প্রকৃত খরচ" else "Total Actual"
      "clear_purchased" -> if (isBn) "ক্রয়কৃত আইটেম মুছুন" else "Clear Purchased"

      // Profile & Settings
      "language" -> if (isBn) "ভাষা" else "Language"
      "dark_mode" -> if (isBn) "ডার্ক মোড" else "Dark Mode"
      "export_data" -> if (isBn) "ডাটা এক্সপোর্ট" else "Export Data"
      "personal_goals" -> if (isBn) "ব্যক্তিগত লক্ষ্য" else "Personal Goals"

      else -> key
    }
  }
}
