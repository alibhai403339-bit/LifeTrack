package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.model.FinanceTransaction
import com.example.ui.LifeTrackViewModel
import com.example.util.LifeTrackStrings

@Composable
fun FinanceScreen(
  viewModel: LifeTrackViewModel,
  modifier: Modifier = Modifier
) {
  val lang by viewModel.language.collectAsState()
  val transactions by viewModel.transactions.collectAsState()
  val monthlyIncome by viewModel.monthlyIncome.collectAsState()
  val monthlyExpense by viewModel.monthlyExpense.collectAsState()
  val userProfile by viewModel.userProfile.collectAsState()

  val monthlyBudget = userProfile?.monthlyBudget ?: 15000.0
  val budgetFraction = (monthlyExpense / monthlyBudget).toFloat().coerceIn(0f, 1f)
  val isBudgetWarning = budgetFraction >= 0.8f

  var filterType by remember { mutableStateOf("all") } // all, income, expense
  var searchQuery by remember { mutableStateOf("") }
  var showAddDialog by remember { mutableStateOf(false) }

  val filteredTransactions = transactions.filter { tx ->
    val matchesType = when (filterType) {
      "income" -> tx.type == "income"
      "expense" -> tx.type == "expense"
      else -> true
    }
    val matchesSearch = searchQuery.isBlank() ||
      tx.category.contains(searchQuery, ignoreCase = true) ||
      tx.notes.contains(searchQuery, ignoreCase = true) ||
      tx.paymentMethod.contains(searchQuery, ignoreCase = true)

    matchesType && matchesSearch
  }.sortedByDescending { it.date }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    floatingActionButton = {
      FloatingActionButton(
        onClick = { showAddDialog = true },
        containerColor = Color(0xFF059669),
        contentColor = Color.White,
        modifier = Modifier.testTag("add_finance_fab")
      ) {
        Icon(Icons.Default.Add, contentDescription = "Add Transaction")
      }
    }
  ) { padding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      item {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = LifeTrackStrings.get("finance", lang),
          style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onBackground
        )
      }

      // Net Balance & Income vs Expense Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(18.dp)) {
            Text(
              text = "Net Balance",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            val net = monthlyIncome - monthlyExpense
            Text(
              text = "${net.toInt()} ৳",
              style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
              color = if (net >= 0) Color(0xFF059669) else Color(0xFFDC2626)
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceAround
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFD1FAE5)),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = Color(0xFF059669), modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text(text = LifeTrackStrings.get("income", lang), style = MaterialTheme.typography.labelSmall)
                  Text(text = "+${monthlyIncome.toInt()} ৳", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = Color(0xFF059669))
                }
              }

              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFEE2E2)),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text(text = LifeTrackStrings.get("expense", lang), style = MaterialTheme.typography.labelSmall)
                  Text(text = "-${monthlyExpense.toInt()} ৳", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = Color(0xFFDC2626))
                }
              }
            }
          }
        }
      }

      // Monthly Budget Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(18.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = LifeTrackStrings.get("monthly_budget", lang),
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
              )
              Text(
                text = "${monthlyExpense.toInt()} / ${monthlyBudget.toInt()} ৳",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = if (isBudgetWarning) Color(0xFFDC2626) else MaterialTheme.colorScheme.primary
              )
            }

            Spacer(modifier = Modifier.height(10.dp))

            LinearProgressIndicator(
              progress = { budgetFraction },
              modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
              color = if (isBudgetWarning) Color(0xFFDC2626) else MaterialTheme.colorScheme.primary,
              trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            if (isBudgetWarning) {
              Spacer(modifier = Modifier.height(10.dp))
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = LifeTrackStrings.get("budget_warning", lang),
                  style = MaterialTheme.typography.labelSmall,
                  color = Color(0xFFDC2626)
                )
              }
            }
          }
        }
      }

      // Search & Filters
      item {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          placeholder = { Text("Search by category, notes, method...") },
          leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp)
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          FilterChip(
            selected = filterType == "all",
            onClick = { filterType = "all" },
            label = { Text("All") }
          )
          FilterChip(
            selected = filterType == "expense",
            onClick = { filterType = "expense" },
            label = { Text(LifeTrackStrings.get("expense", lang)) }
          )
          FilterChip(
            selected = filterType == "income",
            onClick = { filterType = "income" },
            label = { Text(LifeTrackStrings.get("income", lang)) }
          )
        }
      }

      // Transactions List
      if (filteredTransactions.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Text(
                text = "No transactions found.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Spacer(modifier = Modifier.height(10.dp))
              Button(onClick = { showAddDialog = true }) {
                Text("+ Add Transaction")
              }
            }
          }
        }
      } else {
        items(filteredTransactions, key = { it.id }) { tx ->
          TransactionCard(tx = tx, onDelete = { viewModel.deleteTransaction(tx.id) })
        }
      }

      item {
        Spacer(modifier = Modifier.height(80.dp))
      }
    }
  }

  if (showAddDialog) {
    AddTransactionDialog(
      lang = lang,
      onDismiss = { showAddDialog = false },
      onSave = { type, cat, amt, notes, method ->
        viewModel.addTransaction(type, cat, amt, notes, method)
        showAddDialog = false
      }
    )
  }
}

@Composable
private fun TransactionCard(tx: FinanceTransaction, onDelete: () -> Unit) {
  val isIncome = tx.type == "income"
  val color = if (isIncome) Color(0xFF059669) else Color(0xFFDC2626)

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(40.dp)
          .clip(CircleShape)
          .background(color.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          if (isIncome) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
          contentDescription = null,
          tint = color,
          modifier = Modifier.size(20.dp)
        )
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = tx.category,
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )
        Text(
          text = "${tx.date} • ${tx.paymentMethod}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (tx.notes.isNotBlank()) {
          Text(
            text = tx.notes,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      Text(
        text = "${if (isIncome) "+" else "-"}${tx.amount.toInt()} ৳",
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        color = color
      )

      IconButton(onClick = onDelete) {
        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray.copy(alpha = 0.7f), modifier = Modifier.size(20.dp))
      }
    }
  }
}

@Composable
private fun AddTransactionDialog(
  lang: String,
  onDismiss: () -> Unit,
  onSave: (type: String, category: String, amount: Double, notes: String, method: String) -> Unit
) {
  var type by remember { mutableStateOf("expense") }
  var amount by remember { mutableStateOf("") }
  var category by remember { mutableStateOf("Food") }
  var paymentMethod by remember { mutableStateOf("Cash") }
  var notes by remember { mutableStateOf("") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(24.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 6.dp,
      modifier = Modifier.fillMaxWidth(0.95f)
    ) {
      Column(modifier = Modifier.padding(20.dp)) {
        Text(
          text = "New Transaction",
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
        )
        Spacer(modifier = Modifier.height(14.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          FilterChip(
            selected = type == "expense",
            onClick = { type = "expense" },
            label = { Text(LifeTrackStrings.get("expense", lang)) }
          )
          FilterChip(
            selected = type == "income",
            onClick = { type = "income" },
            label = { Text(LifeTrackStrings.get("income", lang)) }
          )
        }
        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = amount,
          onValueChange = { amount = it },
          label = { Text("Amount (৳)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = category,
          onValueChange = { category = it },
          label = { Text("Category (Food, Transport, Bills, Shopping, Salary)") },
          modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          listOf("Cash", "Card", "bKash / Mobile", "Bank").forEach { method ->
            FilterChip(
              selected = paymentMethod == method,
              onClick = { paymentMethod = method },
              label = { Text(method) }
            )
          }
        }
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("Notes (optional)") },
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(20.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
          TextButton(onClick = onDismiss) { Text(LifeTrackStrings.get("cancel", lang)) }
          Spacer(modifier = Modifier.width(8.dp))
          Button(
            onClick = {
              val amt = amount.toDoubleOrNull() ?: 0.0
              if (amt > 0) {
                onSave(type, category, amt, notes, paymentMethod)
              }
            },
            enabled = amount.toDoubleOrNull() != null && amount.toDouble() > 0
          ) {
            Text(LifeTrackStrings.get("save", lang))
          }
        }
      }
    }
  }
}
