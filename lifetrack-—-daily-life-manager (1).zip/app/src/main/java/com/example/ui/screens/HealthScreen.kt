package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DirectionsRun
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.MonitorWeight
import androidx.compose.material.icons.filled.Mood
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.ui.LifeTrackViewModel
import com.example.util.LifeTrackStrings

@Composable
fun HealthScreen(
  viewModel: LifeTrackViewModel,
  modifier: Modifier = Modifier
) {
  val lang by viewModel.language.collectAsState()
  val userProfile by viewModel.userProfile.collectAsState()
  val todayWellness by viewModel.todayWellness.collectAsState()

  var heightCm by remember(userProfile) { mutableStateOf((userProfile?.heightCm ?: 170.0).toString()) }
  var weightKg by remember(userProfile, todayWellness) {
    mutableStateOf((todayWellness?.weightKg ?: userProfile?.weightKg ?: 68.0).toString())
  }
  var steps by remember(todayWellness) { mutableStateOf((todayWellness?.steps ?: 5400).toString()) }
  var mood by remember(todayWellness) { mutableStateOf(todayWellness?.mood ?: "Good") }
  var energyLevel by remember(todayWellness) { mutableIntStateOf(todayWellness?.energyLevel ?: 4) }
  var notes by remember(todayWellness) { mutableStateOf(todayWellness?.notes ?: "") }
  var saveSuccess by remember { mutableStateOf(false) }

  val heightVal = heightCm.toDoubleOrNull() ?: 170.0
  val weightVal = weightKg.toDoubleOrNull() ?: 68.0
  val (bmi, bmiCategory) = viewModel.calculateBmi(weightVal, heightVal)

  val bmiColor = when (bmiCategory) {
    "Underweight" -> Color(0xFF0284C7)
    "Normal weight" -> Color(0xFF059669)
    "Overweight" -> Color(0xFFD97706)
    else -> Color(0xFFDC2626)
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = LifeTrackStrings.get("health", lang),
        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onBackground
      )
    }

    // BMI Calculator Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .clip(CircleShape)
                  .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.MonitorWeight, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
              }
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = LifeTrackStrings.get("bmi_calculator", lang),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
              )
            }
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = bmiColor.copy(alpha = 0.15f)
            ) {
              Text(
                text = "$bmi • $bmiCategory",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = bmiColor,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(
              value = heightCm,
              onValueChange = { heightCm = it; saveSuccess = false },
              label = { Text(LifeTrackStrings.get("height", lang)) },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
              value = weightKg,
              onValueChange = { weightKg = it; saveSuccess = false },
              label = { Text(LifeTrackStrings.get("body_weight", lang)) },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              modifier = Modifier.weight(1f)
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = LifeTrackStrings.get("bmi_disclaimer", lang),
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    }

    // Daily Steps Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFE0F2FE)),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.AutoMirrored.Filled.DirectionsRun, contentDescription = null, tint = Color(0xFF0284C7))
              }
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = "Daily Step Count",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
              )
            }
            Text(
              text = "${steps.toIntOrNull() ?: 0} / ${userProfile?.dailyStepTarget ?: 8000}",
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
              color = Color(0xFF0284C7)
            )
          }

          Spacer(modifier = Modifier.height(12.dp))

          OutlinedTextField(
            value = steps,
            onValueChange = { steps = it; saveSuccess = false },
            label = { Text("Log Steps for Today") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
          )
        }
      }
    }

    // Mood & Energy Tracker Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Mood, contentDescription = null, tint = Color(0xFFD97706))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = LifeTrackStrings.get("mood_tracker", lang),
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Great", "Good", "Okay", "Low", "Tough").forEach { m ->
              FilterChip(
                selected = mood == m,
                onClick = { mood = m; saveSuccess = false },
                label = { Text(m) }
              )
            }
          }

          Spacer(modifier = Modifier.height(16.dp))

          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Bolt, contentDescription = null, tint = Color(0xFF059669))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "${LifeTrackStrings.get("energy_level", lang)}: $energyLevel/5",
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (level in 1..5) {
              FilterChip(
                selected = energyLevel == level,
                onClick = { energyLevel = level; saveSuccess = false },
                label = { Text("$level") }
              )
            }
          }
        }
      }
    }

    // Personal Wellness Notes & Medication Reminders
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.MedicalServices, contentDescription = null, tint = Color(0xFF7C3AED))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Personal Wellness & Medication Notes",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          OutlinedTextField(
            value = notes,
            onValueChange = { notes = it; saveSuccess = false },
            label = { Text("Notes (e.g. Vitamins taken at 9am, Doctor visit on Friday)") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3
          )

          Spacer(modifier = Modifier.height(16.dp))

          Button(
            onClick = {
              val w = weightKg.toDoubleOrNull() ?: 68.0
              val s = steps.toIntOrNull() ?: 0
              viewModel.saveDailyWellness(w, s, mood, energyLevel, notes)
              saveSuccess = true
            },
            modifier = Modifier
              .fillMaxWidth()
              .testTag("save_wellness_button")
          ) {
            Icon(Icons.Default.Save, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text(if (saveSuccess) "Saved Successfully! ✓" else LifeTrackStrings.get("save", lang))
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(80.dp))
    }
  }
}
