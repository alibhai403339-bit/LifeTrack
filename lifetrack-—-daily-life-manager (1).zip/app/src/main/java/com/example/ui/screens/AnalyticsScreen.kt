package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.LifeTrackViewModel
import com.example.util.LifeTrackStrings

@Composable
fun AnalyticsScreen(
  viewModel: LifeTrackViewModel,
  modifier: Modifier = Modifier
) {
  val lang by viewModel.language.collectAsState()
  val routines by viewModel.routines.collectAsState()
  val totalWater by viewModel.totalWaterMl.collectAsState()
  val sleepLogs by viewModel.sleepLogs.collectAsState()
  val workouts by viewModel.workouts.collectAsState()
  val monthlyIncome by viewModel.monthlyIncome.collectAsState()
  val monthlyExpense by viewModel.monthlyExpense.collectAsState()

  var timeRange by remember { mutableStateOf("7d") } // 7d or 30d

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Spacer(modifier = Modifier.height(8.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = LifeTrackStrings.get("analytics", lang),
          style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onBackground
        )

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          FilterChip(
            selected = timeRange == "7d",
            onClick = { timeRange = "7d" },
            label = { Text("7 Days") }
          )
          FilterChip(
            selected = timeRange == "30d",
            onClick = { timeRange = "30d" },
            label = { Text("30 Days") }
          )
        }
      }
    }

    // 1. Routine Consistency Chart
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Text(
            text = "Routine Completion Consistency",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Daily habit adherence score",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(18.dp))

          // Mini bar chart
          val days = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
          val percentages = listOf(80, 100, 65, 90, 85, 70, 95)

          Row(
            modifier = Modifier
              .fillMaxWidth()
              .height(110.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
          ) {
            days.forEachIndexed { i, day ->
              val pct = percentages[i]
              Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
                modifier = Modifier.fillMaxHeight()
              ) {
                Text(text = "$pct%", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(4.dp))
                Box(
                  modifier = Modifier
                    .width(22.dp)
                    .height((pct * 0.75).dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(MaterialTheme.colorScheme.primary)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = day, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }
        }
      }
    }

    // 2. Hydration Volume Trend
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Text(
            text = "Water Intake Trend",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Average: 2,450 ml / day",
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFF0284C7)
          )
          Spacer(modifier = Modifier.height(18.dp))

          val waterAmounts = listOf(2250, 2500, 2000, 2750, 2500, 1800, totalWater.coerceAtLeast(1500))
          val days = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Today")

          Row(
            modifier = Modifier
              .fillMaxWidth()
              .height(110.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
          ) {
            days.forEachIndexed { i, day ->
              val amt = waterAmounts[i]
              val heightDp = (amt / 3000f * 70f).coerceIn(10f, 75f)
              Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
                modifier = Modifier.fillMaxHeight()
              ) {
                Box(
                  modifier = Modifier
                    .width(22.dp)
                    .height(heightDp.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF0284C7))
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = day, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }
        }
      }
    }

    // 3. Sleep Hours Trend
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Text(
            text = "Sleep Duration Trend",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Average: 7.6 hours per night",
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFF7C3AED)
          )
          Spacer(modifier = Modifier.height(18.dp))

          val sleepHrs = listOf(7.5, 8.0, 7.0, 6.8, 8.2, 7.8, 8.0)
          val days = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

          Row(
            modifier = Modifier
              .fillMaxWidth()
              .height(110.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
          ) {
            days.forEachIndexed { i, day ->
              val hrs = sleepHrs[i]
              val heightDp = (hrs / 10.0 * 75.0).coerceIn(10.0, 75.0)
              Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
                modifier = Modifier.fillMaxHeight()
              ) {
                Text(text = "${hrs}h", style = MaterialTheme.typography.labelSmall, color = Color(0xFF7C3AED))
                Spacer(modifier = Modifier.height(4.dp))
                Box(
                  modifier = Modifier
                    .width(22.dp)
                    .height(heightDp.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF7C3AED))
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = day, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }
        }
      }
    }

    // 4. Financial Spending vs Income
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Text(
            text = "Income vs Expenses",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          Spacer(modifier = Modifier.height(14.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(text = "Total Income", style = MaterialTheme.typography.labelSmall)
              Text(text = "+${monthlyIncome.toInt()} ৳", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = Color(0xFF059669))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(text = "Total Expenses", style = MaterialTheme.typography.labelSmall)
              Text(text = "-${monthlyExpense.toInt()} ৳", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = Color(0xFFDC2626))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(text = "Savings Ratio", style = MaterialTheme.typography.labelSmall)
              val ratio = if (monthlyIncome > 0) (((monthlyIncome - monthlyExpense) / monthlyIncome) * 100).toInt() else 0
              Text(text = "$ratio%", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
            }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(80.dp))
    }
  }
}
