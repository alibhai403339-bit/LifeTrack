package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.LifeTrackViewModel
import com.example.util.LifeTrackStrings
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun CalendarHistoryScreen(
  viewModel: LifeTrackViewModel,
  modifier: Modifier = Modifier
) {
  val lang by viewModel.language.collectAsState()
  val selectedDate by viewModel.selectedDate.collectAsState()
  val routines by viewModel.routines.collectAsState()
  val routinePercent by viewModel.routineCompletionPercent.collectAsState()
  val meals by viewModel.meals.collectAsState()
  val totalCalories by viewModel.totalCalories.collectAsState()
  val totalWater by viewModel.totalWaterMl.collectAsState()
  val workouts by viewModel.workouts.collectAsState()
  val caloriesBurned by viewModel.totalCaloriesBurned.collectAsState()
  val transactions by viewModel.transactions.collectAsState()
  val userProfile by viewModel.userProfile.collectAsState()

  val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
  val dayFormat = SimpleDateFormat("EEE", Locale.getDefault())
  val numFormat = SimpleDateFormat("dd", Locale.getDefault())

  // Generate list of the past 14 days
  val daysList = remember {
    val list = mutableListOf<Triple<String, String, String>>() // (fullDate, dayName, dayNum)
    val cal = Calendar.getInstance()
    for (i in 0 until 14) {
      val full = dateFormat.format(cal.time)
      val day = dayFormat.format(cal.time)
      val num = numFormat.format(cal.time)
      list.add(Triple(full, day, num))
      cal.add(Calendar.DAY_OF_YEAR, -1)
    }
    list
  }

  val dateTransactions = transactions.filter { it.date == selectedDate }
  val dateIncome = dateTransactions.filter { it.type == "income" }.sumOf { it.amount }
  val dateExpense = dateTransactions.filter { it.type == "expense" }.sumOf { it.amount }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = LifeTrackStrings.get("calendar", lang),
        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onBackground
      )
    }

    // Horizontal Date Scroller
    item {
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        items(daysList) { (fullDate, dayName, dayNum) ->
          val isSelected = fullDate == selectedDate
          Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
            tonalElevation = if (isSelected) 4.dp else 1.dp,
            modifier = Modifier
              .width(60.dp)
              .height(78.dp)
              .clip(RoundedCornerShape(16.dp))
              .clickable { viewModel.setSelectedDate(fullDate) }
          ) {
            Column(
              modifier = Modifier.fillMaxSize(),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.Center
            ) {
              Text(
                text = dayName,
                style = MaterialTheme.typography.labelSmall,
                color = if (isSelected) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = dayNum,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
              )
            }
          }
        }
      }
    }

    item {
      Text(
        text = "Activity Timeline for $selectedDate",
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
      )
    }

    // Summary Highlights for that day
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
          // Routine status
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier.size(36.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Repeat, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(text = "Routines Completed", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold))
              Text(text = "$routinePercent% completion rate", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(text = "${routines.count { it.isCompleted }}/${routines.size}", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
          }

          // Water status
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier.size(36.dp).clip(CircleShape).background(Color(0xFFE0F2FE)),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.WaterDrop, contentDescription = null, tint = Color(0xFF0284C7), modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(text = "Water Consumed", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold))
              Text(text = "Target: ${userProfile?.waterTargetMl ?: 2500} ml", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(text = "$totalWater ml", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = Color(0xFF0284C7))
          }

          // Meals status
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier.size(36.dp).clip(CircleShape).background(Color(0xFFFEF3C7)),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Restaurant, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(text = "Meals & Calories", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold))
              Text(text = "${meals.size} food items logged", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(text = "${totalCalories.toInt()} kcal", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = Color(0xFFD97706))
          }

          // Workouts status
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier.size(36.dp).clip(CircleShape).background(Color(0xFFD1FAE5)),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.FitnessCenter, contentDescription = null, tint = Color(0xFF059669), modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(text = "Gym & Fitness", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold))
              Text(text = "${workouts.size} exercises completed", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(text = "~${caloriesBurned.toInt()} kcal", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = Color(0xFF059669))
          }

          // Spending status
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier.size(36.dp).clip(CircleShape).background(Color(0xFFFEE2E2)),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.CalendarToday, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(text = "Daily Finances", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold))
              Text(text = "+${dateIncome.toInt()} ৳ income", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(text = "-${dateExpense.toInt()} ৳", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = Color(0xFFDC2626))
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(80.dp))
    }
  }
}
