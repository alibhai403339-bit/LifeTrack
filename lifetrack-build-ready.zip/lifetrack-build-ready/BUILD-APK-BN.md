# LifeTrack APK তৈরি করার নির্দেশনা (মোবাইল থেকেও করা যাবে)

এই ZIP-এ Google AI Studio থেকে পাওয়া Android/Kotlin প্রজেক্টের সঙ্গে GitHub Actions build workflow যোগ করা হয়েছে। এই চ্যাটের পরিবেশে Android SDK/Gradle build environment নেই, তাই এখানে সরাসরি APK তৈরি করা যায়নি। নিচের ধাপে GitHub-এর cloud runner দিয়ে APK build হবে।

## ধাপগুলো

1. GitHub-এ সাইন ইন করুন: https://github.com/
2. নতুন একটি repository তৈরি করুন (উদাহরণ: `lifetrack-android`)। Public বা Private—আপনার পছন্দমতো।
3. এই ZIP-টি extract করুন। ZIP-এর ভেতরের সব ফাইল ও `.github` ফোল্ডারসহ repository-তে upload করুন। `.github/workflows/android-apk.yml` ফাইলটি অবশ্যই থাকবে।
4. সব ফাইল `main` branch-এ commit করুন।
5. Repository-র **Actions** tab খুলুন। **Build LifeTrack APK** workflow নির্বাচন করে **Run workflow** চাপুন। Push করার পর workflow নিজেও চালু হতে পারে।
6. Build সফল হলে workflow run-এর নিচে **Artifacts** অংশে `LifeTrack-debug-APK` নামের artifact পাবেন। সেটি ডাউনলোড করুন।
7. ডাউনলোড করা ZIP extract করে `app-debug.apk` ফাইলটি Android ফোনে খুলে Install করুন। প্রয়োজন হলে Android Settings-এ ওই ফাইল/ব্রাউজারের জন্য “Install unknown apps” অনুমতি দিন। ইনস্টল করার পর নিরাপত্তার জন্য অনুমতিটি বন্ধ করতে পারেন।

## গুরুত্বপূর্ণ

- এটি **debug APK**—নিজের ফোনে পরীক্ষা করার জন্য। Play Store-এ প্রকাশের জন্য আলাদা release signing দরকার।
- প্রথম build ব্যর্থ হলে Actions-এর log খুলে error message দেখুন। এই workflow Android SDK packages ও Gradle dependencies ডাউনলোড করে, তাই internet access প্রয়োজন।
- প্রজেক্টে Firebase config আছে। Firebase Authentication/Firestore ব্যবহার করতে হলে Firebase Console-এ সংশ্লিষ্ট Android app-এর package ID `com.aistudio.lifetrack.xdpwkm`-এর সঙ্গে মেলে কি না এবং Firestore rules ঠিকভাবে deploy করা আছে কি না যাচাই করুন।
- Gemini API key থাকলে সেটি public repository-তে commit করবেন না। `.env` ফাইল বা secret কখনো public করবেন না।
