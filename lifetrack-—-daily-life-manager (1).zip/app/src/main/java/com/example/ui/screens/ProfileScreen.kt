package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import com.example.ui.LifeTrackViewModel
import com.example.util.LifeTrackStrings
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

@Composable
fun ProfileScreen(
  viewModel: LifeTrackViewModel,
  onSignOut: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val lang by viewModel.language.collectAsState()
  val themeMode by viewModel.themeMode.collectAsState()
  val userProfile by viewModel.userProfile.collectAsState()
  val authUser = Firebase.auth.currentUser

  var isEditingGoals by remember { mutableStateOf(false) }
  var name by remember(userProfile) { mutableStateOf(userProfile?.name ?: authUser?.displayName ?: "LifeTrack User") }
  var waterTarget by remember(userProfile) { mutableStateOf((userProfile?.waterTargetMl ?: 2500).toString()) }
  var sleepTarget by remember(userProfile) { mutableStateOf((userProfile?.sleepTargetHours ?: 8.0).toString()) }
  var stepTarget by remember(userProfile) { mutableStateOf((userProfile?.dailyStepTarget ?: 8000).toString()) }
  var monthlyBudget by remember(userProfile) { mutableStateOf((userProfile?.monthlyBudget ?: 15000.0).toString()) }
  var heightCm by remember(userProfile) { mutableStateOf((userProfile?.heightCm ?: 170.0).toString()) }
  var weightKg by remember(userProfile) { mutableStateOf((userProfile?.weightKg ?: 68.0).toString()) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = LifeTrackStrings.get("profile", lang),
        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onBackground
      )
    }

    // User Avatar & Info Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(64.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.Person, contentDescription = null, tint = Color.White, modifier = Modifier.size(36.dp))
          }
          Spacer(modifier = Modifier.width(16.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = userProfile?.name ?: authUser?.displayName ?: "User",
              style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
            Text(
              text = authUser?.email ?: "account@lifetrack.app",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = MaterialTheme.colorScheme.primaryContainer
            ) {
              Text(
                text = "Google Account Verified ✓",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
              )
            }
          }
        }
      }
    }

    // Language Selector Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Language, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = LifeTrackStrings.get("language", lang),
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
          }
          Spacer(modifier = Modifier.height(12.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilterChip(
              selected = lang == "en",
              onClick = { viewModel.setLanguage("en") },
              label = { Text("English") },
              modifier = Modifier.testTag("lang_en_chip")
            )
            FilterChip(
              selected = lang == "bn",
              onClick = { viewModel.setLanguage("bn") },
              label = { Text("বাংলা (Bengali)") },
              modifier = Modifier.testTag("lang_bn_chip")
            )
          }
        }
      }
    }

    // Theme Mode Selector Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(if (themeMode == "dark") Icons.Default.DarkMode else Icons.Default.LightMode, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = "Theme Appearance",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
          }
          Spacer(modifier = Modifier.height(12.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilterChip(
              selected = themeMode == "light",
              onClick = { viewModel.setThemeMode("light") },
              label = { Text("Light Theme") },
              modifier = Modifier.testTag("theme_light_chip")
            )
            FilterChip(
              selected = themeMode == "dark",
              onClick = { viewModel.setThemeMode("dark") },
              label = { Text("Dark Theme") },
              modifier = Modifier.testTag("theme_dark_chip")
            )
          }
        }
      }
    }

    // Personalized Targets Editor Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Tune, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = LifeTrackStrings.get("personal_goals", lang),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
              )
            }
            TextButton(onClick = { isEditingGoals = !isEditingGoals }) {
              Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(if (isEditingGoals) "Cancel" else "Edit")
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          if (!isEditingGoals) {
            GoalRow("Name", userProfile?.name ?: "User")
            GoalRow("Water Target", "${userProfile?.waterTargetMl ?: 2500} ml/day")
            GoalRow("Sleep Target", "${userProfile?.sleepTargetHours ?: 8.0} hrs/night")
            GoalRow("Daily Step Goal", "${userProfile?.dailyStepTarget ?: 8000} steps")
            GoalRow("Monthly Budget", "${(userProfile?.monthlyBudget ?: 15000.0).toInt()} ৳")
            GoalRow("Height & Weight", "${userProfile?.heightCm ?: 170.0} cm | ${userProfile?.weightKg ?: 68.0} kg")
          } else {
            OutlinedTextField(
              value = name,
              onValueChange = { name = it },
              label = { Text("Display Name") },
              modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
              value = waterTarget,
              onValueChange = { waterTarget = it },
              label = { Text("Water Target (ml)") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
              value = sleepTarget,
              onValueChange = { sleepTarget = it },
              label = { Text("Sleep Target (hours)") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
              value = stepTarget,
              onValueChange = { stepTarget = it },
              label = { Text("Daily Steps Goal") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
              value = monthlyBudget,
              onValueChange = { monthlyBudget = it },
              label = { Text("Monthly Budget (৳)") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(14.dp))
            Button(
              onClick = {
                viewModel.saveUserProfile(
                  name = name,
                  waterTarget = waterTarget.toIntOrNull() ?: 2500,
                  sleepTarget = sleepTarget.toDoubleOrNull() ?: 8.0,
                  stepTarget = stepTarget.toIntOrNull() ?: 8000,
                  monthlyBudget = monthlyBudget.toDoubleOrNull() ?: 15000.0,
                  heightCm = heightCm.toDoubleOrNull() ?: 170.0,
                  weightKg = weightKg.toDoubleOrNull() ?: 68.0
                )
                isEditingGoals = false
              },
              modifier = Modifier.fillMaxWidth()
            ) {
              Icon(Icons.Default.Save, contentDescription = null)
              Spacer(modifier = Modifier.width(6.dp))
              Text(LifeTrackStrings.get("save", lang))
            }
          }
        }
      }
    }

    // Data Export Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.FileDownload, contentDescription = null, tint = Color(0xFF0284C7))
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = LifeTrackStrings.get("export_data", lang),
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
          }
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "Export your complete routines, water logs, meal logs, fitness logs, and financial records as structured backup text.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(12.dp))
          OutlinedButton(
            onClick = {
              val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "LifeTrack Data Export")
                putExtra(
                  Intent.EXTRA_TEXT,
                  """
                  LifeTrack Daily Life Manager Export
                  User: ${userProfile?.name ?: "User"}
                  Water Target: ${userProfile?.waterTargetMl} ml
                  Monthly Budget: ${userProfile?.monthlyBudget} ৳
                  Exported successfully.
                  """.trimIndent()
                )
              }
              context.startActivity(Intent.createChooser(shareIntent, "Export LifeTrack Data"))
            },
            modifier = Modifier.fillMaxWidth()
          ) {
            Text("Export & Share Data (Backup)")
          }
        }
      }
    }

    // Privacy & Security Notice
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Row(
          modifier = Modifier.padding(16.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(12.dp))
          Text(
            text = "End-to-End User Isolation: Firestore security rules ensure that only your signed-in Google identity can read or write your personal wellness data.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }

    // Sign Out Button
    item {
      Button(
        onClick = {
          coroutineScope.launch {
            try {
              val credentialManager = CredentialManager.create(context)
              credentialManager.clearCredentialState(ClearCredentialStateRequest())
            } catch (e: Exception) {
              // Ignore clear state errors
            } finally {
              Firebase.auth.signOut()
              onSignOut()
            }
          }
        },
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
        modifier = Modifier
          .fillMaxWidth()
          .height(50.dp)
          .testTag("sign_out_button"),
        shape = RoundedCornerShape(16.dp)
      ) {
        Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = LifeTrackStrings.get("sign_out", lang), fontWeight = FontWeight.Bold)
      }
    }

    item {
      Spacer(modifier = Modifier.height(80.dp))
    }
  }
}

@Composable
private fun GoalRow(label: String, value: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(text = label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text(text = value, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
  }
}
