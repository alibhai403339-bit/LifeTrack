package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.LifeTrackViewModel
import com.example.util.LifeTrackStrings

@Composable
fun OnboardingDialog(
  viewModel: LifeTrackViewModel,
  currentLang: String,
  onDismiss: () -> Unit
) {
  var step by remember { mutableStateOf(1) }
  var lang by remember { mutableStateOf(currentLang) }
  var name by remember { mutableStateOf("") }
  var wakeUpTime by remember { mutableStateOf("06:30 AM") }
  var bedTime by remember { mutableStateOf("10:30 PM") }
  var waterTarget by remember { mutableStateOf("2500") }
  var sleepTarget by remember { mutableStateOf("8.0") }
  var stepTarget by remember { mutableStateOf("8000") }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.92f)
        .padding(16.dp),
      shape = RoundedCornerShape(28.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 6.dp
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(24.dp)
          .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Box(
          modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primaryContainer),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            Icons.Default.AutoAwesome,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(28.dp)
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
          text = if (lang == "bn") "লাইফট্র্যাকে স্বাগতম!" else "Welcome to LifeTrack!",
          style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.primary
        )

        Text(
          text = if (lang == "bn") "আপনার প্রতিদিনের জীবনকে সাজিয়ে তুলুন (ধাপ $step/৩)"
                 else "Personalize your daily routine (Step $step of 3)",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(24.dp))

        if (step == 1) {
          // Language & Name
          Text(
            text = if (lang == "bn") "পছন্দের ভাষা নির্বাচন করুন" else "Choose Your Language",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold
          )
          Spacer(modifier = Modifier.height(8.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FilterChip(
              selected = lang == "en",
              onClick = {
                lang = "en"
                viewModel.setLanguage("en")
              },
              label = { Text("English") },
              modifier = Modifier.testTag("onboard_lang_en")
            )
            FilterChip(
              selected = lang == "bn",
              onClick = {
                lang = "bn"
                viewModel.setLanguage("bn")
              },
              label = { Text("বাংলা (Bengali)") },
              modifier = Modifier.testTag("onboard_lang_bn")
            )
          }

          Spacer(modifier = Modifier.height(16.dp))

          OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text(if (lang == "bn") "আপনার নাম" else "Your Name") },
            modifier = Modifier
              .fillMaxWidth()
              .testTag("onboard_name_input")
          )
        } else if (step == 2) {
          // Routines & Sleep
          Text(
            text = if (lang == "bn") "ঘুম ও জেগে ওঠার সময়সূচী" else "Sleep & Wake Routine",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold
          )
          Spacer(modifier = Modifier.height(12.dp))

          OutlinedTextField(
            value = wakeUpTime,
            onValueChange = { wakeUpTime = it },
            label = { Text(LifeTrackStrings.get("wake_up_time", lang)) },
            modifier = Modifier.fillMaxWidth()
          )

          Spacer(modifier = Modifier.height(12.dp))

          OutlinedTextField(
            value = bedTime,
            onValueChange = { bedTime = it },
            label = { Text(LifeTrackStrings.get("bedtime", lang)) },
            modifier = Modifier.fillMaxWidth()
          )

          Spacer(modifier = Modifier.height(12.dp))

          OutlinedTextField(
            value = sleepTarget,
            onValueChange = { sleepTarget = it },
            label = { Text(if (lang == "bn") "ঘুমের লক্ষ্য (ঘণ্টা)" else "Target Sleep Hours") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
          )
        } else {
          // Hydration & Fitness Goals
          Text(
            text = if (lang == "bn") "স্বাস্থ্য ও ফিটনেস লক্ষ্য" else "Hydration & Health Targets",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold
          )
          Spacer(modifier = Modifier.height(12.dp))

          OutlinedTextField(
            value = waterTarget,
            onValueChange = { waterTarget = it },
            label = { Text(if (lang == "bn") "দৈনিক পানি পানের লক্ষ্য (মি.লি.)" else "Daily Water Target (ml)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
          )

          Spacer(modifier = Modifier.height(12.dp))

          OutlinedTextField(
            value = stepTarget,
            onValueChange = { stepTarget = it },
            label = { Text(if (lang == "bn") "দৈনিক পদক্ষেপের লক্ষ্য" else "Daily Step Goal") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
          )
        }

        Spacer(modifier = Modifier.height(28.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          OutlinedButton(
            onClick = onDismiss,
            shape = RoundedCornerShape(12.dp)
          ) {
            Text(LifeTrackStrings.get("skip", lang))
          }

          Button(
            onClick = {
              if (step < 3) {
                step += 1
              } else {
                viewModel.saveUserProfile(
                  name = if (name.isNotBlank()) name else "User",
                  waterTarget = waterTarget.toIntOrNull() ?: 2500,
                  sleepTarget = sleepTarget.toDoubleOrNull() ?: 8.0,
                  stepTarget = stepTarget.toIntOrNull() ?: 8000,
                  monthlyBudget = 15000.0,
                  heightCm = 170.0,
                  weightKg = 68.0,
                  wakeUpTime = wakeUpTime,
                  bedTime = bedTime
                )
                onDismiss()
              }
            },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.testTag("onboard_next_button")
          ) {
            Text(if (step < 3) LifeTrackStrings.get("next", lang) else LifeTrackStrings.get("get_started", lang))
          }
        }
      }
    }
  }
}
