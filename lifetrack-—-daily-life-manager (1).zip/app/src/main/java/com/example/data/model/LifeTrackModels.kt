package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class UserProfile(
  @DocumentId val id: String = "",
  val userId: String = "",
  val name: String = "User",
  val email: String = "",
  val language: String = "en",
  val themeMode: String = "light",
  val wakeUpTime: String = "06:30 AM",
  val bedTime: String = "10:30 PM",
  val waterTargetMl: Int = 2500,
  val sleepTargetHours: Double = 8.0,
  val dailyStepTarget: Int = 8000,
  val monthlyBudget: Double = 15000.0,
  val heightCm: Double = 170.0,
  val weightKg: Double = 68.0,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class RoutineItem(
  @DocumentId val id: String = "",
  val userId: String = "",
  val title: String = "",
  val scheduledTime: String = "07:00 AM",
  val iconName: String = "habit",
  val isCompleted: Boolean = false,
  val isRecurring: Boolean = true,
  val category: String = "Morning",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class MealEntry(
  @DocumentId val id: String = "",
  val userId: String = "",
  val mealType: String = "breakfast", // breakfast, lunch, dinner, snack
  val foodName: String = "",
  val quantity: String = "1 serving",
  val mealTime: String = "08:00 AM",
  val calories: Double = 0.0,
  val proteinG: Double = 0.0,
  val carbsG: Double = 0.0,
  val fatG: Double = 0.0,
  val date: String = "", // YYYY-MM-DD
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class WaterLog(
  @DocumentId val id: String = "",
  val userId: String = "",
  val amountMl: Int = 250,
  val date: String = "", // YYYY-MM-DD
  val time: String = "", // HH:mm
  @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class WorkoutLog(
  @DocumentId val id: String = "",
  val userId: String = "",
  val exerciseName: String = "",
  val category: String = "strength", // strength, cardio, flexibility, other
  val sets: Int = 3,
  val reps: Int = 10,
  val weightKg: Double = 0.0,
  val durationMinutes: Int = 30,
  val caloriesBurned: Double = 0.0,
  val date: String = "", // YYYY-MM-DD
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class SleepLog(
  @DocumentId val id: String = "",
  val userId: String = "",
  val sleepTime: String = "11:00 PM",
  val wakeTime: String = "07:00 AM",
  val durationMinutes: Int = 480,
  val qualityRating: Int = 4, // 1 to 5
  val date: String = "", // YYYY-MM-DD
  val notes: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class FinanceTransaction(
  @DocumentId val id: String = "",
  val userId: String = "",
  val type: String = "expense", // income or expense
  val category: String = "Food",
  val amount: Double = 0.0,
  val date: String = "", // YYYY-MM-DD
  val notes: String = "",
  val paymentMethod: String = "Cash", // Cash, Card, Mobile Banking, Bank
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class ShoppingItem(
  @DocumentId val id: String = "",
  val userId: String = "",
  val name: String = "",
  val category: String = "Groceries", // Groceries, Vegetables, Fruits, Meat, Household, Other
  val quantity: String = "1 kg",
  val estimatedPrice: Double = 0.0,
  val actualPrice: Double = 0.0,
  val isPurchased: Boolean = false,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class TaskItem(
  @DocumentId val id: String = "",
  val userId: String = "",
  val title: String = "",
  val priority: String = "medium", // low, medium, high
  val dueDate: String = "", // YYYY-MM-DD
  val dueTime: String = "",
  val category: String = "Personal",
  val isCompleted: Boolean = false,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class WellnessLog(
  @DocumentId val id: String = "",
  val userId: String = "",
  val date: String = "", // YYYY-MM-DD
  val weightKg: Double = 0.0,
  val steps: Int = 0,
  val mood: String = "Good", // Great, Good, Okay, Low, Tough
  val energyLevel: Int = 4, // 1 to 5
  val notes: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
)
