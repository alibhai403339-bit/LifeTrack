package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.UserProfile
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LifeTrackRepositoryRuleTest : FirestoreEmulatorTestBase() {

  @Test
  fun saveProfile_authenticatedUser_createsDocumentSuccessfully(): Unit = runBlocking {
    val uid = signInTestUser(ALICE_EMAIL)
    val repository = LifeTrackRepository(firestore)

    val profile = UserProfile(
      userId = uid,
      name = "Alice",
      language = "en",
      waterTargetMl = 2800
    )

    val saveResult = withTimeout(DEFAULT_TIMEOUT_MS) { repository.saveProfile(profile) }
    assertTrue("Save profile failed with: ${saveResult.exceptionOrNull()?.message}", saveResult.isSuccess)

    val fetchedProfile = withTimeout(FLOW_TIMEOUT_MS) {
      repository.observeProfile().first()
    }
    assertNotNull(fetchedProfile)
    assertEquals("Alice", fetchedProfile?.name)
    assertEquals(2800, fetchedProfile?.waterTargetMl)
  }

  @Test
  fun addRoutine_authenticatedUser_createsAndReadsRoutine(): Unit = runBlocking {
    signInTestUser(ALICE_EMAIL)
    val repository = LifeTrackRepository(firestore)

    val addResult = withTimeout(DEFAULT_TIMEOUT_MS) {
      repository.addRoutine("Morning Meditation", "07:00 AM", "meditation", "Mindfulness")
    }
    assertTrue(addResult.isSuccess)
    val routineId = addResult.getOrThrow()
    assertTrue(routineId.isNotEmpty())

    val routines = withTimeout(FLOW_TIMEOUT_MS) {
      repository.observeRoutines().first()
    }
    assertTrue(routines.any { it.id == routineId && it.title == "Morning Meditation" })
  }

  @Test
  fun observeRoutines_crossUserIsolation_bobCannotReadAliceRoutines(): Unit = runBlocking {
    signInTestUser(ALICE_EMAIL)
    val aliceRepo = LifeTrackRepository(firestore)
    val routineId = withTimeout(DEFAULT_TIMEOUT_MS) {
      aliceRepo.addRoutine("Alice Secret Habit", "06:00 AM", "secret", "Personal").getOrThrow()
    }

    // Switch to Bob
    val bobUid = signInTestUser(BOB_EMAIL)
    val bobRepo = LifeTrackRepository(firestore)

    // Bob observing his own routines should NOT contain Alice's routine
    val bobRoutines = withTimeout(FLOW_TIMEOUT_MS) {
      bobRepo.observeRoutines().first()
    }
    assertFalse(bobRoutines.any { it.id == routineId })
  }

  @Test
  fun observeRoutines_unauthenticatedUser_failsWithPermissionDenied(): Unit = runBlocking {
    auth.signOut()
    val repository = LifeTrackRepository(firestore)

    var caught = false
    try {
      withTimeout(FLOW_TIMEOUT_MS) {
        repository.observeRoutines().first()
      }
    } catch (e: Exception) {
      caught = true
      val firestoreException = e.unwrapFirestoreException()
      val isAuthOrPermission = e is IllegalStateException ||
        firestoreException?.code == FirebaseFirestoreException.Code.PERMISSION_DENIED
      assertTrue(isAuthOrPermission)
    }
    assertTrue("Expected exception when unauthenticated", caught)
  }

  private companion object {
    const val ALICE_EMAIL = "alice@lifetrack.test"
    const val BOB_EMAIL = "bob@lifetrack.test"
    const val DEFAULT_TIMEOUT_MS = 5000L
    const val FLOW_TIMEOUT_MS = 4000L
  }
}
