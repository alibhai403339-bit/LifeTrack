package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.FinanceTransaction
import com.example.data.model.MealEntry
import com.example.data.model.RoutineItem
import com.example.data.model.ShoppingItem
import com.example.data.model.SleepLog
import com.example.data.model.TaskItem
import com.example.data.model.UserProfile
import com.example.data.model.WaterLog
import com.example.data.model.WellnessLog
import com.example.data.model.WorkoutLog
import com.example.data.util.OperationType
import com.example.data.util.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class LifeTrackRepository(val db: FirebaseFirestore) {

  constructor(context: Context) : this(
    FirebaseFirestore.getInstance(
      context.applicationContext.getString(R.string.firestore_database_id)
    )
  )

  private val auth = Firebase.auth

  fun requireUserId(): String {
    return auth.currentUser?.uid
      ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
  }

  // ----------------- PROFILE -----------------
  fun observeProfile(): Flow<UserProfile?> = flow {
    val uid = auth.currentUser?.uid
    if (uid == null) {
      emit(null)
      return@flow
    }
    val docRef = db.collection("users").document(uid)
    emitAll(
      docRef.snapshots()
        .map { snapshot -> snapshot.toObject(UserProfile::class.java) }
        .catch { error ->
          if (error is Exception) handleFirestoreError(error, OperationType.GET, docRef.path)
          throw error
        }
    )
  }

  suspend fun saveProfile(profile: UserProfile): Result<Unit> {
    return try {
      val uid = requireUserId()
      val docRef = db.collection("users").document(uid)
      val data = hashMapOf(
        "userId" to uid,
        "name" to profile.name,
        "email" to (auth.currentUser?.email ?: profile.email),
        "language" to profile.language,
        "themeMode" to profile.themeMode,
        "wakeUpTime" to profile.wakeUpTime,
        "bedTime" to profile.bedTime,
        "waterTargetMl" to profile.waterTargetMl,
        "sleepTargetHours" to profile.sleepTargetHours,
        "dailyStepTarget" to profile.dailyStepTarget,
        "monthlyBudget" to profile.monthlyBudget,
        "heightCm" to profile.heightCm,
        "weightKg" to profile.weightKg,
        "createdAt" to (profile.createdAt ?: FieldValue.serverTimestamp()),
        "updatedAt" to FieldValue.serverTimestamp()
      )
      docRef.set(data, SetOptions.merge()).await()
      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, "users/${auth.currentUser?.uid}")
      Result.failure(e)
    }
  }

  // ----------------- ROUTINES -----------------
  fun observeRoutines(): Flow<List<RoutineItem>> = flow {
    val uid = requireUserId()
    val colRef = db.collection("users").document(uid).collection("routines")
    emitAll(
      colRef.snapshots()
        .map { snapshot -> snapshot.toObjects(RoutineItem::class.java) }
        .catch { error ->
          if (error is Exception) handleFirestoreError(error, OperationType.LIST, colRef.path)
          throw error
        }
    )
  }

  suspend fun addRoutine(title: String, time: String, icon: String, category: String): Result<String> {
    return try {
      val uid = requireUserId()
      val colRef = db.collection("users").document(uid).collection("routines")
      val docRef = colRef.document()
      val data = hashMapOf(
        "userId" to uid,
        "title" to title,
        "scheduledTime" to time,
        "iconName" to icon,
        "isCompleted" to false,
        "isRecurring" to true,
        "category" to category,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
      )
      docRef.set(data).await()
      Result.success(docRef.id)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, "users/${auth.currentUser?.uid}/routines")
      Result.failure(e)
    }
  }

  suspend fun toggleRoutine(routineId: String, isCompleted: Boolean): Result<Unit> {
    return try {
      val uid = requireUserId()
      val docRef = db.collection("users").document(uid).collection("routines").document(routineId)
      docRef.update(mapOf("isCompleted" to isCompleted, "updatedAt" to FieldValue.serverTimestamp())).await()
      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, "users/${auth.currentUser?.uid}/routines/$routineId")
      Result.failure(e)
    }
  }

  suspend fun deleteRoutine(routineId: String): Result<Unit> {
    return try {
      val uid = requireUserId()
      db.collection("users").document(uid).collection("routines").document(routineId).delete().await()
      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, "users/${auth.currentUser?.uid}/routines/$routineId")
      Result.failure(e)
    }
  }

  // ----------------- MEALS -----------------
  fun observeMeals(date: String): Flow<List<MealEntry>> = flow {
    val uid = requireUserId()
    val colRef = db.collection("users").document(uid).collection("meals")
    emitAll(
      colRef.whereEqualTo("date", date).snapshots()
        .map { snapshot -> snapshot.toObjects(MealEntry::class.java) }
        .catch { error ->
          if (error is Exception) handleFirestoreError(error, OperationType.LIST, colRef.path)
          throw error
        }
    )
  }

  suspend fun addMeal(meal: MealEntry): Result<String> {
    return try {
      val uid = requireUserId()
      val colRef = db.collection("users").document(uid).collection("meals")
      val docRef = colRef.document()
      val data = hashMapOf(
        "userId" to uid,
        "mealType" to meal.mealType,
        "foodName" to meal.foodName,
        "quantity" to meal.quantity,
        "mealTime" to meal.mealTime,
        "calories" to meal.calories,
        "proteinG" to meal.proteinG,
        "carbsG" to meal.carbsG,
        "fatG" to meal.fatG,
        "date" to meal.date,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
      )
      docRef.set(data).await()
      Result.success(docRef.id)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, "users/${auth.currentUser?.uid}/meals")
      Result.failure(e)
    }
  }

  suspend fun deleteMeal(mealId: String): Result<Unit> {
    return try {
      val uid = requireUserId()
      db.collection("users").document(uid).collection("meals").document(mealId).delete().await()
      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, "users/${auth.currentUser?.uid}/meals/$mealId")
      Result.failure(e)
    }
  }

  // ----------------- WATER LOGS -----------------
  fun observeWaterLogs(date: String): Flow<List<WaterLog>> = flow {
    val uid = requireUserId()
    val colRef = db.collection("users").document(uid).collection("waterLogs")
    emitAll(
      colRef.whereEqualTo("date", date).snapshots()
        .map { snapshot -> snapshot.toObjects(WaterLog::class.java) }
        .catch { error ->
          if (error is Exception) handleFirestoreError(error, OperationType.LIST, colRef.path)
          throw error
        }
    )
  }

  suspend fun addWaterLog(amountMl: Int, date: String, time: String): Result<String> {
    return try {
      val uid = requireUserId()
      val colRef = db.collection("users").document(uid).collection("waterLogs")
      val docRef = colRef.document()
      val data = hashMapOf(
        "userId" to uid,
        "amountMl" to amountMl,
        "date" to date,
        "time" to time,
        "createdAt" to FieldValue.serverTimestamp()
      )
      docRef.set(data).await()
      Result.success(docRef.id)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, "users/${auth.currentUser?.uid}/waterLogs")
      Result.failure(e)
    }
  }

  suspend fun deleteWaterLog(logId: String): Result<Unit> {
    return try {
      val uid = requireUserId()
      db.collection("users").document(uid).collection("waterLogs").document(logId).delete().await()
      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, "users/${auth.currentUser?.uid}/waterLogs/$logId")
      Result.failure(e)
    }
  }

  // ----------------- WORKOUTS -----------------
  fun observeWorkouts(date: String): Flow<List<WorkoutLog>> = flow {
    val uid = requireUserId()
    val colRef = db.collection("users").document(uid).collection("workouts")
    emitAll(
      colRef.whereEqualTo("date", date).snapshots()
        .map { snapshot -> snapshot.toObjects(WorkoutLog::class.java) }
        .catch { error ->
          if (error is Exception) handleFirestoreError(error, OperationType.LIST, colRef.path)
          throw error
        }
    )
  }

  suspend fun addWorkout(workout: WorkoutLog): Result<String> {
    return try {
      val uid = requireUserId()
      val colRef = db.collection("users").document(uid).collection("workouts")
      val docRef = colRef.document()
      val data = hashMapOf(
        "userId" to uid,
        "exerciseName" to workout.exerciseName,
        "category" to workout.category,
        "sets" to workout.sets,
        "reps" to workout.reps,
        "weightKg" to workout.weightKg,
        "durationMinutes" to workout.durationMinutes,
        "caloriesBurned" to workout.caloriesBurned,
        "date" to workout.date,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
      )
      docRef.set(data).await()
      Result.success(docRef.id)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, "users/${auth.currentUser?.uid}/workouts")
      Result.failure(e)
    }
  }

  suspend fun deleteWorkout(workoutId: String): Result<Unit> {
    return try {
      val uid = requireUserId()
      db.collection("users").document(uid).collection("workouts").document(workoutId).delete().await()
      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, "users/${auth.currentUser?.uid}/workouts/$workoutId")
      Result.failure(e)
    }
  }

  // ----------------- SLEEP LOGS -----------------
  fun observeSleepLogs(): Flow<List<SleepLog>> = flow {
    val uid = requireUserId()
    val colRef = db.collection("users").document(uid).collection("sleepLogs")
    emitAll(
      colRef.snapshots()
        .map { snapshot -> snapshot.toObjects(SleepLog::class.java) }
        .catch { error ->
          if (error is Exception) handleFirestoreError(error, OperationType.LIST, colRef.path)
          throw error
        }
    )
  }

  suspend fun addSleepLog(sleepLog: SleepLog): Result<String> {
    return try {
      val uid = requireUserId()
      val colRef = db.collection("users").document(uid).collection("sleepLogs")
      val docRef = colRef.document()
      val data = hashMapOf(
        "userId" to uid,
        "sleepTime" to sleepLog.sleepTime,
        "wakeTime" to sleepLog.wakeTime,
        "durationMinutes" to sleepLog.durationMinutes,
        "qualityRating" to sleepLog.qualityRating,
        "date" to sleepLog.date,
        "notes" to sleepLog.notes,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
      )
      docRef.set(data).await()
      Result.success(docRef.id)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, "users/${auth.currentUser?.uid}/sleepLogs")
      Result.failure(e)
    }
  }

  // ----------------- TRANSACTIONS (FINANCE) -----------------
  fun observeTransactions(): Flow<List<FinanceTransaction>> = flow {
    val uid = requireUserId()
    val colRef = db.collection("users").document(uid).collection("transactions")
    emitAll(
      colRef.snapshots()
        .map { snapshot -> snapshot.toObjects(FinanceTransaction::class.java) }
        .catch { error ->
          if (error is Exception) handleFirestoreError(error, OperationType.LIST, colRef.path)
          throw error
        }
    )
  }

  suspend fun addTransaction(tx: FinanceTransaction): Result<String> {
    return try {
      val uid = requireUserId()
      val colRef = db.collection("users").document(uid).collection("transactions")
      val docRef = colRef.document()
      val data = hashMapOf(
        "userId" to uid,
        "type" to tx.type,
        "category" to tx.category,
        "amount" to tx.amount,
        "date" to tx.date,
        "notes" to tx.notes,
        "paymentMethod" to tx.paymentMethod,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
      )
      docRef.set(data).await()
      Result.success(docRef.id)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, "users/${auth.currentUser?.uid}/transactions")
      Result.failure(e)
    }
  }

  suspend fun deleteTransaction(txId: String): Result<Unit> {
    return try {
      val uid = requireUserId()
      db.collection("users").document(uid).collection("transactions").document(txId).delete().await()
      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, "users/${auth.currentUser?.uid}/transactions/$txId")
      Result.failure(e)
    }
  }

  // ----------------- SHOPPING ITEMS -----------------
  fun observeShoppingItems(): Flow<List<ShoppingItem>> = flow {
    val uid = requireUserId()
    val colRef = db.collection("users").document(uid).collection("shoppingItems")
    emitAll(
      colRef.snapshots()
        .map { snapshot -> snapshot.toObjects(ShoppingItem::class.java) }
        .catch { error ->
          if (error is Exception) handleFirestoreError(error, OperationType.LIST, colRef.path)
          throw error
        }
    )
  }

  suspend fun addShoppingItem(item: ShoppingItem): Result<String> {
    return try {
      val uid = requireUserId()
      val colRef = db.collection("users").document(uid).collection("shoppingItems")
      val docRef = colRef.document()
      val data = hashMapOf(
        "userId" to uid,
        "name" to item.name,
        "category" to item.category,
        "quantity" to item.quantity,
        "estimatedPrice" to item.estimatedPrice,
        "actualPrice" to item.actualPrice,
        "isPurchased" to item.isPurchased,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
      )
      docRef.set(data).await()
      Result.success(docRef.id)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, "users/${auth.currentUser?.uid}/shoppingItems")
      Result.failure(e)
    }
  }

  suspend fun toggleShoppingItem(itemId: String, isPurchased: Boolean, actualPrice: Double? = null): Result<Unit> {
    return try {
      val uid = requireUserId()
      val docRef = db.collection("users").document(uid).collection("shoppingItems").document(itemId)
      val updates = mutableMapOf<String, Any>(
        "isPurchased" to isPurchased,
        "updatedAt" to FieldValue.serverTimestamp()
      )
      if (actualPrice != null) {
        updates["actualPrice"] = actualPrice
      }
      docRef.update(updates).await()
      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, "users/${auth.currentUser?.uid}/shoppingItems/$itemId")
      Result.failure(e)
    }
  }

  suspend fun deleteShoppingItem(itemId: String): Result<Unit> {
    return try {
      val uid = requireUserId()
      db.collection("users").document(uid).collection("shoppingItems").document(itemId).delete().await()
      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, "users/${auth.currentUser?.uid}/shoppingItems/$itemId")
      Result.failure(e)
    }
  }

  // ----------------- TASKS -----------------
  fun observeTasks(): Flow<List<TaskItem>> = flow {
    val uid = requireUserId()
    val colRef = db.collection("users").document(uid).collection("tasks")
    emitAll(
      colRef.snapshots()
        .map { snapshot -> snapshot.toObjects(TaskItem::class.java) }
        .catch { error ->
          if (error is Exception) handleFirestoreError(error, OperationType.LIST, colRef.path)
          throw error
        }
    )
  }

  suspend fun addTask(task: TaskItem): Result<String> {
    return try {
      val uid = requireUserId()
      val colRef = db.collection("users").document(uid).collection("tasks")
      val docRef = colRef.document()
      val data = hashMapOf(
        "userId" to uid,
        "title" to task.title,
        "priority" to task.priority,
        "dueDate" to task.dueDate,
        "dueTime" to task.dueTime,
        "category" to task.category,
        "isCompleted" to task.isCompleted,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
      )
      docRef.set(data).await()
      Result.success(docRef.id)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, "users/${auth.currentUser?.uid}/tasks")
      Result.failure(e)
    }
  }

  suspend fun toggleTask(taskId: String, isCompleted: Boolean): Result<Unit> {
    return try {
      val uid = requireUserId()
      val docRef = db.collection("users").document(uid).collection("tasks").document(taskId)
      docRef.update(mapOf("isCompleted" to isCompleted, "updatedAt" to FieldValue.serverTimestamp())).await()
      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, "users/${auth.currentUser?.uid}/tasks/$taskId")
      Result.failure(e)
    }
  }

  suspend fun deleteTask(taskId: String): Result<Unit> {
    return try {
      val uid = requireUserId()
      db.collection("users").document(uid).collection("tasks").document(taskId).delete().await()
      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, "users/${auth.currentUser?.uid}/tasks/$taskId")
      Result.failure(e)
    }
  }

  // ----------------- WELLNESS -----------------
  fun observeWellnessLogs(): Flow<List<WellnessLog>> = flow {
    val uid = requireUserId()
    val colRef = db.collection("users").document(uid).collection("wellnessLogs")
    emitAll(
      colRef.snapshots()
        .map { snapshot -> snapshot.toObjects(WellnessLog::class.java) }
        .catch { error ->
          if (error is Exception) handleFirestoreError(error, OperationType.LIST, colRef.path)
          throw error
        }
    )
  }

  suspend fun saveWellnessLog(log: WellnessLog): Result<String> {
    return try {
      val uid = requireUserId()
      val colRef = db.collection("users").document(uid).collection("wellnessLogs")
      val docRef = if (log.id.isNotBlank()) colRef.document(log.id) else colRef.document()
      val data = hashMapOf(
        "userId" to uid,
        "date" to log.date,
        "weightKg" to log.weightKg,
        "steps" to log.steps,
        "mood" to log.mood,
        "energyLevel" to log.energyLevel,
        "notes" to log.notes,
        "createdAt" to (log.createdAt ?: FieldValue.serverTimestamp()),
        "updatedAt" to FieldValue.serverTimestamp()
      )
      docRef.set(data).await()
      Result.success(docRef.id)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, "users/${auth.currentUser?.uid}/wellnessLogs")
      Result.failure(e)
    }
  }
}
