package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.model.MealEntry
import com.example.ui.LifeTrackViewModel
import com.example.util.LifeTrackStrings

@Composable
fun MealScreen(
  viewModel: LifeTrackViewModel,
  modifier: Modifier = Modifier
) {
  val lang by viewModel.language.collectAsState()
  val meals by viewModel.meals.collectAsState()
  val totalCalories by viewModel.totalCalories.collectAsState()

  val mealTypes = listOf("breakfast", "lunch", "dinner", "snack")
  var selectedTabIndex by remember { mutableIntStateOf(0) }
  var showAddDialog by remember { mutableStateOf(false) }

  val currentType = mealTypes[selectedTabIndex]
  val filteredMeals = meals.filter { it.mealType == currentType }

  val totalProtein = meals.sumOf { it.proteinG }
  val totalCarbs = meals.sumOf { it.carbsG }
  val totalFat = meals.sumOf { it.fatG }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    floatingActionButton = {
      FloatingActionButton(
        onClick = { showAddDialog = true },
        containerColor = Color(0xFFD97706),
        contentColor = Color.White,
        modifier = Modifier.testTag("add_meal_fab")
      ) {
        Icon(Icons.Default.Add, contentDescription = "Add Meal")
      }
    }
  ) { padding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      item {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = LifeTrackStrings.get("meals", lang),
          style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onBackground
        )
      }

      // Nutrition Summary Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(18.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = "Today's Intake",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                  text = "${totalCalories.toInt()} kcal",
                  style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                  color = Color(0xFFD97706)
                )
              }
              Box(
                modifier = Modifier
                  .size(44.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFFEF3C7)),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.Restaurant, contentDescription = null, tint = Color(0xFFD97706))
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Macros row
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceAround
            ) {
              MacroColumn("Protein", "${totalProtein.toInt()}g", Color(0xFF0284C7))
              MacroColumn("Carbs", "${totalCarbs.toInt()}g", Color(0xFF059669))
              MacroColumn("Fat", "${totalFat.toInt()}g", Color(0xFFDC2626))
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Mandatory Disclaimer
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = LifeTrackStrings.get("nutrition_disclaimer", lang),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      }

      // Meal Type Tabs
      item {
        TabRow(
          selectedTabIndex = selectedTabIndex,
          containerColor = MaterialTheme.colorScheme.surface,
          contentColor = MaterialTheme.colorScheme.primary,
          modifier = Modifier.clip(RoundedCornerShape(12.dp))
        ) {
          mealTypes.forEachIndexed { index, type ->
            Tab(
              selected = selectedTabIndex == index,
              onClick = { selectedTabIndex = index },
              text = { Text(LifeTrackStrings.get(type, lang)) }
            )
          }
        }
      }

      // Meal list for this tab
      if (filteredMeals.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Text(
                text = "No ${LifeTrackStrings.get(currentType, lang)} logged yet.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Spacer(modifier = Modifier.height(12.dp))
              Button(
                onClick = { showAddDialog = true },
                shape = RoundedCornerShape(12.dp)
              ) {
                Text("+ Log ${LifeTrackStrings.get(currentType, lang)}")
              }
            }
          }
        }
      } else {
        items(filteredMeals, key = { it.id }) { meal ->
          MealItemCard(meal = meal, onDelete = { viewModel.deleteMeal(meal.id) })
        }
      }

      item {
        Spacer(modifier = Modifier.height(80.dp))
      }
    }
  }

  if (showAddDialog) {
    AddMealDialog(
      defaultType = currentType,
      lang = lang,
      onDismiss = { showAddDialog = false },
      onSave = { type, food, qty, cal, p, c, f ->
        viewModel.addMeal(type, food, qty, cal, p, c, f)
        showAddDialog = false
      }
    )
  }
}

@Composable
private fun MacroColumn(title: String, value: String, color: Color) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(text = title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text(text = value, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = color)
  }
}

@Composable
private fun MealItemCard(meal: MealEntry, onDelete: () -> Unit) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(text = meal.foodName, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold))
        Text(
          text = "${meal.quantity} • ${meal.mealTime}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (meal.proteinG > 0 || meal.carbsG > 0 || meal.fatG > 0) {
          Text(
            text = "P: ${meal.proteinG.toInt()}g | C: ${meal.carbsG.toInt()}g | F: ${meal.fatG.toInt()}g",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFFFEF3C7)
      ) {
        Text(
          text = "${meal.calories.toInt()} kcal",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
          color = Color(0xFFD97706),
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
      }

      IconButton(onClick = onDelete) {
        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray.copy(alpha = 0.7f), modifier = Modifier.size(20.dp))
      }
    }
  }
}

@Composable
private fun AddMealDialog(
  defaultType: String,
  lang: String,
  onDismiss: () -> Unit,
  onSave: (type: String, food: String, qty: String, cal: Double, p: Double, c: Double, f: Double) -> Unit
) {
  var mealType by remember { mutableStateOf(defaultType) }
  var foodName by remember { mutableStateOf("") }
  var quantity by remember { mutableStateOf("1 serving") }
  var calories by remember { mutableStateOf("") }
  var protein by remember { mutableStateOf("") }
  var carbs by remember { mutableStateOf("") }
  var fat by remember { mutableStateOf("") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(24.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 6.dp,
      modifier = Modifier.fillMaxWidth(0.95f)
    ) {
      Column(modifier = Modifier.padding(20.dp)) {
        Text(
          text = LifeTrackStrings.get("add", lang) + " " + LifeTrackStrings.get("meals", lang),
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
        )
        Spacer(modifier = Modifier.height(14.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          listOf("breakfast", "lunch", "dinner", "snack").forEach { type ->
            FilterChip(
              selected = mealType == type,
              onClick = { mealType = type },
              label = { Text(LifeTrackStrings.get(type, lang)) }
            )
          }
        }
        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = foodName,
          onValueChange = { foodName = it },
          label = { Text("Food Name") },
          modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = quantity,
          onValueChange = { quantity = it },
          label = { Text("Quantity (e.g., 1 plate, 200g)") },
          modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = calories,
            onValueChange = { calories = it },
            label = { Text("Calories (kcal)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = protein,
            onValueChange = { protein = it },
            label = { Text("Protein (g)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f)
          )
        }
        Spacer(modifier = Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = carbs,
            onValueChange = { carbs = it },
            label = { Text("Carbs (g)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = fat,
            onValueChange = { fat = it },
            label = { Text("Fat (g)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f)
          )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.End
        ) {
          TextButton(onClick = onDismiss) { Text(LifeTrackStrings.get("cancel", lang)) }
          Spacer(modifier = Modifier.width(8.dp))
          Button(
            onClick = {
              if (foodName.isNotBlank()) {
                onSave(
                  mealType,
                  foodName,
                  quantity,
                  calories.toDoubleOrNull() ?: 0.0,
                  protein.toDoubleOrNull() ?: 0.0,
                  carbs.toDoubleOrNull() ?: 0.0,
                  fat.toDoubleOrNull() ?: 0.0
                )
              }
            },
            enabled = foodName.isNotBlank()
          ) {
            Text(LifeTrackStrings.get("save", lang))
          }
        }
      }
    }
  }
}
