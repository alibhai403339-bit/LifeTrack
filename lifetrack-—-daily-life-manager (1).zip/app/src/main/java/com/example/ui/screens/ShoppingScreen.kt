package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.model.ShoppingItem
import com.example.ui.LifeTrackViewModel
import com.example.util.LifeTrackStrings

@Composable
fun ShoppingScreen(
  viewModel: LifeTrackViewModel,
  modifier: Modifier = Modifier
) {
  val lang by viewModel.language.collectAsState()
  val items by viewModel.shoppingItems.collectAsState()

  var selectedCategory by remember { mutableStateOf("All") }
  var showAddDialog by remember { mutableStateOf(false) }

  val categories = listOf("All", "Groceries", "Vegetables", "Fruits", "Meat", "Household", "Other")

  val filteredItems = items.filter {
    selectedCategory == "All" || it.category.equals(selectedCategory, ignoreCase = true)
  }

  val totalEstimated = items.sumOf { it.estimatedPrice }
  val totalActual = items.filter { it.isPurchased }.sumOf { if (it.actualPrice > 0) it.actualPrice else it.estimatedPrice }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    floatingActionButton = {
      FloatingActionButton(
        onClick = { showAddDialog = true },
        containerColor = MaterialTheme.colorScheme.primary,
        contentColor = Color.White,
        modifier = Modifier.testTag("add_shopping_fab")
      ) {
        Icon(Icons.Default.Add, contentDescription = "Add Item")
      }
    }
  ) { padding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      item {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = LifeTrackStrings.get("shopping_list", lang),
          style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onBackground
        )
      }

      // Cost Summary Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(18.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceAround
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = LifeTrackStrings.get("total_estimated", lang), style = MaterialTheme.typography.labelSmall)
                Text(text = "${totalEstimated.toInt()} ৳", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = Color(0xFF0284C7))
              }
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = LifeTrackStrings.get("total_actual", lang), style = MaterialTheme.typography.labelSmall)
                Text(text = "${totalActual.toInt()} ৳", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
              }
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = "Purchased", style = MaterialTheme.typography.labelSmall)
                Text(text = "${items.count { it.isPurchased }}/${items.size}", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
              }
            }

            if (items.any { it.isPurchased }) {
              Spacer(modifier = Modifier.height(14.dp))
              OutlinedButton(
                onClick = { viewModel.clearPurchasedShopping() },
                modifier = Modifier.fillMaxWidth()
              ) {
                Icon(Icons.Default.ClearAll, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(LifeTrackStrings.get("clear_purchased", lang))
              }
            }
          }
        }
      }

      // Category Chips
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          categories.take(4).forEach { cat ->
            FilterChip(
              selected = selectedCategory == cat,
              onClick = { selectedCategory = cat },
              label = { Text(cat) }
            )
          }
        }
      }

      // Items List
      if (filteredItems.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Text(
                text = "Shopping list is empty.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Spacer(modifier = Modifier.height(10.dp))
              Button(onClick = { showAddDialog = true }) {
                Text("+ Add Grocery Item")
              }
            }
          }
        }
      } else {
        items(filteredItems, key = { it.id }) { item ->
          ShoppingItemRow(
            item = item,
            onToggle = { viewModel.toggleShoppingItem(item.id, !item.isPurchased) },
            onDelete = { viewModel.deleteShoppingItem(item.id) }
          )
        }
      }

      item {
        Spacer(modifier = Modifier.height(80.dp))
      }
    }
  }

  if (showAddDialog) {
    AddShoppingItemDialog(
      lang = lang,
      onDismiss = { showAddDialog = false },
      onSave = { name, cat, qty, price ->
        viewModel.addShoppingItem(name, cat, qty, price)
        showAddDialog = false
      }
    )
  }
}

@Composable
private fun ShoppingItemRow(
  item: ShoppingItem,
  onToggle: () -> Unit,
  onDelete: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (item.isPurchased) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
                       else MaterialTheme.colorScheme.surface
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Checkbox(
        checked = item.isPurchased,
        onCheckedChange = { onToggle() },
        colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
      )

      Spacer(modifier = Modifier.width(8.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = item.name,
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.SemiBold,
            textDecoration = if (item.isPurchased) TextDecoration.LineThrough else TextDecoration.None
          ),
          color = if (item.isPurchased) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                  else MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = "${item.quantity} • ${item.category}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      Text(
        text = "${item.estimatedPrice.toInt()} ৳",
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
        color = if (item.isPurchased) MaterialTheme.colorScheme.primary else Color(0xFF0284C7)
      )

      IconButton(onClick = onDelete) {
        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray.copy(alpha = 0.7f), modifier = Modifier.size(20.dp))
      }
    }
  }
}

@Composable
private fun AddShoppingItemDialog(
  lang: String,
  onDismiss: () -> Unit,
  onSave: (name: String, category: String, quantity: String, price: Double) -> Unit
) {
  var name by remember { mutableStateOf("") }
  var category by remember { mutableStateOf("Groceries") }
  var quantity by remember { mutableStateOf("1 kg") }
  var estimatedPrice by remember { mutableStateOf("") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(24.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 6.dp,
      modifier = Modifier.fillMaxWidth(0.95f)
    ) {
      Column(modifier = Modifier.padding(20.dp)) {
        Text(
          text = "Add Shopping Item",
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
        )
        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("Item Name (e.g. Milk, Rice, Olive Oil)") },
          modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = category,
            onValueChange = { category = it },
            label = { Text("Category") },
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = quantity,
            onValueChange = { quantity = it },
            label = { Text("Quantity") },
            modifier = Modifier.weight(1f)
          )
        }
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = estimatedPrice,
          onValueChange = { estimatedPrice = it },
          label = { Text("Estimated Price (৳)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(20.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
          TextButton(onClick = onDismiss) { Text(LifeTrackStrings.get("cancel", lang)) }
          Spacer(modifier = Modifier.width(8.dp))
          Button(
            onClick = {
              if (name.isNotBlank()) {
                onSave(name, category, quantity, estimatedPrice.toDoubleOrNull() ?: 0.0)
              }
            },
            enabled = name.isNotBlank()
          ) {
            Text(LifeTrackStrings.get("save", lang))
          }
        }
      }
    }
  }
}
