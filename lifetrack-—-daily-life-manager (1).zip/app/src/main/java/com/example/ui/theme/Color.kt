package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Palette - Fresh Wellness Green & Clean Modern Neutrals
val PrimaryGreen = Color(0xFF059669)
val PrimaryLight = Color(0xFF34D399)
val PrimaryContainer = Color(0xFFD1FAE5)
val OnPrimaryContainer = Color(0xFF064E3B)

val SecondaryTeal = Color(0xFF0D9488)
val SecondaryContainer = Color(0xFFCCFBF1)
val OnSecondaryContainer = Color(0xFF134E48)

val AccentAmber = Color(0xFFD97706)
val AccentAmberContainer = Color(0xFFFEF3C7)
val OnAccentAmberContainer = Color(0xFF78350F)

val AccentBlue = Color(0xFF0284C7)
val AccentBlueContainer = Color(0xFFE0F2FE)
val OnAccentBlueContainer = Color(0xFF0369A1)

val BackgroundLight = Color(0xFFF8FAF9)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFEDF2EE)
val OutlineLight = Color(0xFFD5DFD8)
val TextPrimaryLight = Color(0xFF19251D)
val TextSecondaryLight = Color(0xFF5A6E60)

// Dark Theme Palette - Deep Forest Obsidian
val PrimaryDark = Color(0xFF34D399)
val PrimaryContainerDark = Color(0xFF064E3B)
val OnPrimaryContainerDark = Color(0xFFA7F3D0)

val SecondaryDark = Color(0xFF2DD4BF)
val SecondaryContainerDark = Color(0xFF134E48)

val BackgroundDark = Color(0xFF0F1713)
val SurfaceDark = Color(0xFF16231C)
val SurfaceVariantDark = Color(0xFF1F3027)
val OutlineDark = Color(0xFF2E4437)
val TextPrimaryDark = Color(0xFFE8F1EC)
val TextSecondaryDark = Color(0xFF9AB2A2)
