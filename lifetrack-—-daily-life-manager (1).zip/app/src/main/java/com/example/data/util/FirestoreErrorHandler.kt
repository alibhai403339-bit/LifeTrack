package com.example.data.util

import android.util.Log

enum class OperationType {
  GET,
  LIST,
  CREATE,
  UPDATE,
  DELETE
}

fun handleFirestoreError(e: Exception, operationType: OperationType, path: String) {
  val message = e.localizedMessage ?: "Unknown error"
  Log.e(
    "FirestoreError",
    """{"operation": "$operationType", "path": "$path", "error": "$message"}"""
  )
}
