package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.model.TaskItem
import com.example.ui.LifeTrackViewModel
import com.example.util.LifeTrackStrings

@Composable
fun TasksScreen(
  viewModel: LifeTrackViewModel,
  modifier: Modifier = Modifier
) {
  val lang by viewModel.language.collectAsState()
  val tasks by viewModel.tasks.collectAsState()

  var filterStatus by remember { mutableStateOf("pending") } // pending, completed, all
  var showAddDialog by remember { mutableStateOf(false) }

  val filteredTasks = tasks.filter {
    when (filterStatus) {
      "pending" -> !it.isCompleted
      "completed" -> it.isCompleted
      else -> true
    }
  }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    floatingActionButton = {
      FloatingActionButton(
        onClick = { showAddDialog = true },
        containerColor = Color(0xFF7C3AED),
        contentColor = Color.White,
        modifier = Modifier.testTag("add_task_fab")
      ) {
        Icon(Icons.Default.Add, contentDescription = "Add Task")
      }
    }
  ) { padding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      item {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = LifeTrackStrings.get("tasks", lang),
          style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onBackground
        )
      }

      // Filter Status Chips
      item {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          FilterChip(
            selected = filterStatus == "pending",
            onClick = { filterStatus = "pending" },
            label = { Text("Pending (${tasks.count { !it.isCompleted }})") }
          )
          FilterChip(
            selected = filterStatus == "completed",
            onClick = { filterStatus = "completed" },
            label = { Text("Completed (${tasks.count { it.isCompleted }})") }
          )
          FilterChip(
            selected = filterStatus == "all",
            onClick = { filterStatus = "all" },
            label = { Text("All (${tasks.size})") }
          )
        }
      }

      if (filteredTasks.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Text(
                text = if (filterStatus == "pending") "No pending tasks! Everything done." else "No tasks found.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Spacer(modifier = Modifier.height(10.dp))
              Button(onClick = { showAddDialog = true }) {
                Text("+ Create Task")
              }
            }
          }
        }
      } else {
        items(filteredTasks, key = { it.id }) { task ->
          TaskCard(
            task = task,
            onToggle = { viewModel.toggleTask(task.id, task.isCompleted) },
            onDelete = { viewModel.deleteTask(task.id) }
          )
        }
      }

      item {
        Spacer(modifier = Modifier.height(80.dp))
      }
    }
  }

  if (showAddDialog) {
    AddTaskDialog(
      lang = lang,
      onDismiss = { showAddDialog = false },
      onSave = { title, priority, dueDate, time, cat ->
        viewModel.addTask(title, priority, dueDate, time, cat)
        showAddDialog = false
      }
    )
  }
}

@Composable
private fun TaskCard(
  task: TaskItem,
  onToggle: () -> Unit,
  onDelete: () -> Unit
) {
  val priorityColor = when (task.priority) {
    "high" -> Color(0xFFDC2626)
    "medium" -> Color(0xFFD97706)
    else -> Color(0xFF059669)
  }

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (task.isCompleted) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
                       else MaterialTheme.colorScheme.surface
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Checkbox(
        checked = task.isCompleted,
        onCheckedChange = { onToggle() },
        colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
      )

      Spacer(modifier = Modifier.width(8.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(8.dp)
              .clip(CircleShape)
              .background(priorityColor)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = task.title,
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.SemiBold,
              textDecoration = if (task.isCompleted) TextDecoration.LineThrough else TextDecoration.None
            ),
            color = if (task.isCompleted) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    else MaterialTheme.colorScheme.onSurface
          )
        }
        Text(
          text = "${task.category} • ${task.priority.uppercase()} Priority",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      IconButton(onClick = onDelete) {
        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray.copy(alpha = 0.7f), modifier = Modifier.size(20.dp))
      }
    }
  }
}

@Composable
private fun AddTaskDialog(
  lang: String,
  onDismiss: () -> Unit,
  onSave: (title: String, priority: String, dueDate: String, time: String, category: String) -> Unit
) {
  var title by remember { mutableStateOf("") }
  var priority by remember { mutableStateOf("medium") }
  var category by remember { mutableStateOf("Personal") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(24.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 6.dp,
      modifier = Modifier.fillMaxWidth(0.95f)
    ) {
      Column(modifier = Modifier.padding(20.dp)) {
        Text(
          text = "Create Task & Reminder",
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
        )
        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Task Description") },
          modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(10.dp))

        Text(text = "Priority", style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          listOf("low", "medium", "high").forEach { p ->
            FilterChip(
              selected = priority == p,
              onClick = { priority = p },
              label = { Text(p.replaceFirstChar { it.uppercase() }) }
            )
          }
        }
        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = category,
          onValueChange = { category = it },
          label = { Text("Category (Personal, Work, Fitness, Health)") },
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(20.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
          TextButton(onClick = onDismiss) { Text(LifeTrackStrings.get("cancel", lang)) }
          Spacer(modifier = Modifier.width(8.dp))
          Button(
            onClick = {
              if (title.isNotBlank()) onSave(title, priority, "", "", category)
            },
            enabled = title.isNotBlank()
          ) {
            Text(LifeTrackStrings.get("save", lang))
          }
        }
      }
    }
  }
}
