package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.ui.LifeTrackViewModel
import com.example.util.LifeTrackStrings

enum class QuickActionType {
  WATER,
  MEAL,
  WORKOUT,
  EXPENSE,
  TASK,
  ROUTINE
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickAddBottomSheet(
  viewModel: LifeTrackViewModel,
  lang: String,
  onDismiss: () -> Unit
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  var selectedAction by remember { mutableStateOf<QuickActionType?>(null) }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 24.dp)
        .padding(bottom = 32.dp)
        .verticalScroll(rememberScrollState())
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = if (selectedAction == null) LifeTrackStrings.get("quick_add", lang)
                 else selectedAction!!.name.lowercase().replaceFirstChar { it.uppercase() },
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurface
        )
        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "Close")
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      if (selectedAction == null) {
        // Grid of Action Buttons
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          ActionGridCard(
            title = LifeTrackStrings.get("water", lang),
            icon = Icons.Default.WaterDrop,
            color = Color(0xFF0284C7),
            modifier = Modifier.weight(1f),
            onClick = { selectedAction = QuickActionType.WATER }
          )
          ActionGridCard(
            title = LifeTrackStrings.get("meals", lang),
            icon = Icons.Default.Restaurant,
            color = Color(0xFFD97706),
            modifier = Modifier.weight(1f),
            onClick = { selectedAction = QuickActionType.MEAL }
          )
        }
        Spacer(modifier = Modifier.height(12.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          ActionGridCard(
            title = LifeTrackStrings.get("workout", lang),
            icon = Icons.Default.FitnessCenter,
            color = Color(0xFF059669),
            modifier = Modifier.weight(1f),
            onClick = { selectedAction = QuickActionType.WORKOUT }
          )
          ActionGridCard(
            title = LifeTrackStrings.get("expense", lang),
            icon = Icons.Default.AttachMoney,
            color = Color(0xFFDC2626),
            modifier = Modifier.weight(1f),
            onClick = { selectedAction = QuickActionType.EXPENSE }
          )
        }
        Spacer(modifier = Modifier.height(12.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          ActionGridCard(
            title = LifeTrackStrings.get("tasks", lang),
            icon = Icons.AutoMirrored.Filled.Assignment,
            color = Color(0xFF7C3AED),
            modifier = Modifier.weight(1f),
            onClick = { selectedAction = QuickActionType.TASK }
          )
          ActionGridCard(
            title = LifeTrackStrings.get("routine", lang),
            icon = Icons.Default.Repeat,
            color = Color(0xFF0D9488),
            modifier = Modifier.weight(1f),
            onClick = { selectedAction = QuickActionType.ROUTINE }
          )
        }
      } else {
        when (selectedAction) {
          QuickActionType.WATER -> {
            QuickWaterForm(viewModel, lang) { onDismiss() }
          }
          QuickActionType.MEAL -> {
            QuickMealForm(viewModel, lang) { onDismiss() }
          }
          QuickActionType.WORKOUT -> {
            QuickWorkoutForm(viewModel, lang) { onDismiss() }
          }
          QuickActionType.EXPENSE -> {
            QuickFinanceForm(viewModel, lang) { onDismiss() }
          }
          QuickActionType.TASK -> {
            QuickTaskForm(viewModel, lang) { onDismiss() }
          }
          QuickActionType.ROUTINE -> {
            QuickRoutineForm(viewModel, lang) { onDismiss() }
          }
          else -> {}
        }
      }
    }
  }
}

@Composable
private fun ActionGridCard(
  title: String,
  icon: ImageVector,
  color: Color,
  modifier: Modifier = Modifier,
  onClick: () -> Unit
) {
  Card(
    modifier = modifier
      .clickable { onClick() }
      .testTag("quick_action_${title.lowercase()}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.12f))
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Box(
        modifier = Modifier
          .size(44.dp)
          .clip(CircleShape)
          .background(color),
        contentAlignment = Alignment.Center
      ) {
        Icon(icon, contentDescription = title, tint = Color.White, modifier = Modifier.size(24.dp))
      }
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
        color = MaterialTheme.colorScheme.onSurface
      )
    }
  }
}

// --- Quick Forms ---
@Composable
private fun QuickWaterForm(viewModel: LifeTrackViewModel, lang: String, onDone: () -> Unit) {
  var customMl by remember { mutableStateOf("") }
  Column {
    Text(
      text = LifeTrackStrings.get("water_intake", lang),
      style = MaterialTheme.typography.bodyMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Spacer(modifier = Modifier.height(16.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
      Button(
        onClick = { viewModel.addWater(250); onDone() },
        modifier = Modifier.weight(1f)
      ) { Text(LifeTrackStrings.get("add_250", lang)) }
      Button(
        onClick = { viewModel.addWater(500); onDone() },
        modifier = Modifier.weight(1f)
      ) { Text(LifeTrackStrings.get("add_500", lang)) }
      Button(
        onClick = { viewModel.addWater(1000); onDone() },
        modifier = Modifier.weight(1f)
      ) { Text(LifeTrackStrings.get("add_1000", lang)) }
    }
    Spacer(modifier = Modifier.height(16.dp))
    OutlinedTextField(
      value = customMl,
      onValueChange = { customMl = it },
      label = { Text("Custom Amount (ml)") },
      keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
      modifier = Modifier.fillMaxWidth()
    )
    Spacer(modifier = Modifier.height(16.dp))
    Button(
      onClick = {
        val ml = customMl.toIntOrNull() ?: 250
        viewModel.addWater(ml)
        onDone()
      },
      modifier = Modifier.fillMaxWidth(),
      enabled = customMl.isNotBlank()
    ) {
      Text(LifeTrackStrings.get("add", lang))
    }
  }
}

@Composable
private fun QuickMealForm(viewModel: LifeTrackViewModel, lang: String, onDone: () -> Unit) {
  var mealType by remember { mutableStateOf("breakfast") }
  var foodName by remember { mutableStateOf("") }
  var calories by remember { mutableStateOf("") }
  var protein by remember { mutableStateOf("") }
  var carbs by remember { mutableStateOf("") }
  var fat by remember { mutableStateOf("") }

  Column {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      listOf("breakfast", "lunch", "dinner", "snack").forEach { type ->
        FilterChip(
          selected = mealType == type,
          onClick = { mealType = type },
          label = { Text(LifeTrackStrings.get(type, lang)) }
        )
      }
    }
    Spacer(modifier = Modifier.height(12.dp))
    OutlinedTextField(
      value = foodName,
      onValueChange = { foodName = it },
      label = { Text("Food Name") },
      modifier = Modifier.fillMaxWidth()
    )
    Spacer(modifier = Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      OutlinedTextField(
        value = calories,
        onValueChange = { calories = it },
        label = { Text("Calories (kcal)") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.weight(1f)
      )
      OutlinedTextField(
        value = protein,
        onValueChange = { protein = it },
        label = { Text("Protein (g)") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.weight(1f)
      )
    }
    Spacer(modifier = Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      OutlinedTextField(
        value = carbs,
        onValueChange = { carbs = it },
        label = { Text("Carbs (g)") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.weight(1f)
      )
      OutlinedTextField(
        value = fat,
        onValueChange = { fat = it },
        label = { Text("Fat (g)") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.weight(1f)
      )
    }
    Spacer(modifier = Modifier.height(16.dp))
    Button(
      onClick = {
        viewModel.addMeal(
          type = mealType,
          foodName = foodName,
          quantity = "1 serving",
          calories = calories.toDoubleOrNull() ?: 0.0,
          protein = protein.toDoubleOrNull() ?: 0.0,
          carbs = carbs.toDoubleOrNull() ?: 0.0,
          fat = fat.toDoubleOrNull() ?: 0.0
        )
        onDone()
      },
      modifier = Modifier.fillMaxWidth(),
      enabled = foodName.isNotBlank()
    ) {
      Text(LifeTrackStrings.get("save", lang))
    }
  }
}

@Composable
private fun QuickWorkoutForm(viewModel: LifeTrackViewModel, lang: String, onDone: () -> Unit) {
  var name by remember { mutableStateOf("") }
  var category by remember { mutableStateOf("strength") }
  var sets by remember { mutableStateOf("3") }
  var reps by remember { mutableStateOf("10") }
  var weight by remember { mutableStateOf("0") }
  var duration by remember { mutableStateOf("30") }
  var calories by remember { mutableStateOf("150") }

  Column {
    OutlinedTextField(
      value = name,
      onValueChange = { name = it },
      label = { Text("Exercise Name (e.g. Bench Press, Running)") },
      modifier = Modifier.fillMaxWidth()
    )
    Spacer(modifier = Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      FilterChip(selected = category == "strength", onClick = { category = "strength" }, label = { Text("Strength") })
      FilterChip(selected = category == "cardio", onClick = { category = "cardio" }, label = { Text("Cardio") })
      FilterChip(selected = category == "flexibility", onClick = { category = "flexibility" }, label = { Text("Flexibility") })
    }
    Spacer(modifier = Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      OutlinedTextField(
        value = sets,
        onValueChange = { sets = it },
        label = { Text("Sets") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.weight(1f)
      )
      OutlinedTextField(
        value = reps,
        onValueChange = { reps = it },
        label = { Text("Reps") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.weight(1f)
      )
      OutlinedTextField(
        value = weight,
        onValueChange = { weight = it },
        label = { Text("Weight (kg)") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.weight(1f)
      )
    }
    Spacer(modifier = Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      OutlinedTextField(
        value = duration,
        onValueChange = { duration = it },
        label = { Text("Duration (min)") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.weight(1f)
      )
      OutlinedTextField(
        value = calories,
        onValueChange = { calories = it },
        label = { Text("Est. Calories") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.weight(1f)
      )
    }
    Spacer(modifier = Modifier.height(16.dp))
    Button(
      onClick = {
        viewModel.addWorkout(
          name = name,
          category = category,
          sets = sets.toIntOrNull() ?: 3,
          reps = reps.toIntOrNull() ?: 10,
          weightKg = weight.toDoubleOrNull() ?: 0.0,
          durationMinutes = duration.toIntOrNull() ?: 30,
          caloriesBurned = calories.toDoubleOrNull() ?: 0.0
        )
        onDone()
      },
      modifier = Modifier.fillMaxWidth(),
      enabled = name.isNotBlank()
    ) {
      Text(LifeTrackStrings.get("save", lang))
    }
  }
}

@Composable
private fun QuickFinanceForm(viewModel: LifeTrackViewModel, lang: String, onDone: () -> Unit) {
  var type by remember { mutableStateOf("expense") }
  var amount by remember { mutableStateOf("") }
  var category by remember { mutableStateOf("Food") }
  var paymentMethod by remember { mutableStateOf("Cash") }
  var notes by remember { mutableStateOf("") }

  Column {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      FilterChip(
        selected = type == "expense",
        onClick = { type = "expense" },
        label = { Text(LifeTrackStrings.get("expense", lang)) }
      )
      FilterChip(
        selected = type == "income",
        onClick = { type = "income" },
        label = { Text(LifeTrackStrings.get("income", lang)) }
      )
    }
    Spacer(modifier = Modifier.height(12.dp))
    OutlinedTextField(
      value = amount,
      onValueChange = { amount = it },
      label = { Text("Amount (৳ / $)") },
      keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
      modifier = Modifier.fillMaxWidth()
    )
    Spacer(modifier = Modifier.height(8.dp))
    OutlinedTextField(
      value = category,
      onValueChange = { category = it },
      label = { Text("Category (e.g. Food, Transport, Bills, Salary)") },
      modifier = Modifier.fillMaxWidth()
    )
    Spacer(modifier = Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
      listOf("Cash", "Card", "bKash / Mobile", "Bank").forEach { method ->
        FilterChip(
          selected = paymentMethod == method,
          onClick = { paymentMethod = method },
          label = { Text(method) }
        )
      }
    }
    Spacer(modifier = Modifier.height(8.dp))
    OutlinedTextField(
      value = notes,
      onValueChange = { notes = it },
      label = { Text("Notes (optional)") },
      modifier = Modifier.fillMaxWidth()
    )
    Spacer(modifier = Modifier.height(16.dp))
    Button(
      onClick = {
        val amt = amount.toDoubleOrNull() ?: 0.0
        if (amt > 0) {
          viewModel.addTransaction(type, category, amt, notes, paymentMethod)
          onDone()
        }
      },
      modifier = Modifier.fillMaxWidth(),
      enabled = amount.toDoubleOrNull() != null && amount.toDouble() > 0
    ) {
      Text(LifeTrackStrings.get("save", lang))
    }
  }
}

@Composable
private fun QuickTaskForm(viewModel: LifeTrackViewModel, lang: String, onDone: () -> Unit) {
  var title by remember { mutableStateOf("") }
  var priority by remember { mutableStateOf("medium") }
  var category by remember { mutableStateOf("Personal") }

  Column {
    OutlinedTextField(
      value = title,
      onValueChange = { title = it },
      label = { Text("Task Title") },
      modifier = Modifier.fillMaxWidth()
    )
    Spacer(modifier = Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      listOf("low", "medium", "high").forEach { prio ->
        FilterChip(
          selected = priority == prio,
          onClick = { priority = prio },
          label = { Text(prio.replaceFirstChar { it.uppercase() }) }
        )
      }
    }
    Spacer(modifier = Modifier.height(8.dp))
    OutlinedTextField(
      value = category,
      onValueChange = { category = it },
      label = { Text("Category") },
      modifier = Modifier.fillMaxWidth()
    )
    Spacer(modifier = Modifier.height(16.dp))
    Button(
      onClick = {
        viewModel.addTask(title, priority, "", "", category)
        onDone()
      },
      modifier = Modifier.fillMaxWidth(),
      enabled = title.isNotBlank()
    ) {
      Text(LifeTrackStrings.get("save", lang))
    }
  }
}

@Composable
private fun QuickRoutineForm(viewModel: LifeTrackViewModel, lang: String, onDone: () -> Unit) {
  var title by remember { mutableStateOf("") }
  var time by remember { mutableStateOf("07:00 AM") }
  var category by remember { mutableStateOf("Morning") }

  Column {
    OutlinedTextField(
      value = title,
      onValueChange = { title = it },
      label = { Text("Habit / Routine Name (e.g. Morning Walk, Reading)") },
      modifier = Modifier.fillMaxWidth()
    )
    Spacer(modifier = Modifier.height(8.dp))
    OutlinedTextField(
      value = time,
      onValueChange = { time = it },
      label = { Text("Scheduled Time") },
      modifier = Modifier.fillMaxWidth()
    )
    Spacer(modifier = Modifier.height(8.dp))
    OutlinedTextField(
      value = category,
      onValueChange = { category = it },
      label = { Text("Category (e.g. Morning, Evening, Health)") },
      modifier = Modifier.fillMaxWidth()
    )
    Spacer(modifier = Modifier.height(16.dp))
    Button(
      onClick = {
        viewModel.addRoutine(title, time, "habit", category)
        onDone()
      },
      modifier = Modifier.fillMaxWidth(),
      enabled = title.isNotBlank()
    ) {
      Text(LifeTrackStrings.get("save", lang))
    }
  }
}
