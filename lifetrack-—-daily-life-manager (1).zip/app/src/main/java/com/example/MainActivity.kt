package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.LifeTrackViewModel
import com.example.ui.components.OnboardingDialog
import com.example.ui.components.QuickAddBottomSheet
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CalendarHistoryScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.FinanceScreen
import com.example.ui.screens.FitnessScreen
import com.example.ui.screens.HealthScreen
import com.example.ui.screens.MealScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.RoutineScreen
import com.example.ui.screens.ShoppingScreen
import com.example.ui.screens.SleepScreen
import com.example.ui.screens.TasksScreen
import com.example.ui.screens.WaterScreen
import com.example.ui.theme.LifeTrackTheme
import com.example.util.LifeTrackStrings
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

data class TopLevelDestination(
  val route: String,
  val labelKey: String,
  val icon: ImageVector
)

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      AppRoot()
    }
  }
}

@Composable
fun AppRoot() {
  var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }

  DisposableEffect(Unit) {
    val listener = FirebaseAuth.AuthStateListener { auth ->
      currentUser = auth.currentUser
    }
    Firebase.auth.addAuthStateListener(listener)
    onDispose {
      Firebase.auth.removeAuthStateListener(listener)
    }
  }

  val user = currentUser
  if (user == null) {
    LifeTrackTheme {
      Surface(modifier = Modifier.fillMaxSize()) {
        AuthScreen(
          onAuthSuccess = {
            currentUser = Firebase.auth.currentUser
          }
        )
      }
    }
  } else {
    val viewModel: LifeTrackViewModel = viewModel(key = user.uid)
    val themeMode by viewModel.themeMode.collectAsState()

    val isDark = when (themeMode) {
      "dark" -> true
      "light" -> false
      else -> isSystemInDarkTheme()
    }

    LifeTrackTheme(darkTheme = isDark) {
      Surface(modifier = Modifier.fillMaxSize()) {
        MainNavigationContent(
          viewModel = viewModel,
          onSignOut = {
            Firebase.auth.signOut()
            currentUser = null
          }
        )
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainNavigationContent(
  viewModel: LifeTrackViewModel,
  onSignOut: () -> Unit
) {
  val navController = rememberNavController()
  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = navBackStackEntry?.destination?.route ?: "home"

  val lang by viewModel.language.collectAsState()
  val userProfile by viewModel.userProfile.collectAsState()
  val showQuickAdd by viewModel.showQuickAddModal.collectAsState()

  var hasCompletedOnboarding by remember { mutableStateOf(false) }
  val showOnboarding = userProfile == null && !hasCompletedOnboarding

  val destinations = listOf(
    TopLevelDestination("home", "home", Icons.Default.Home),
    TopLevelDestination("routine", "routine", Icons.Default.Repeat),
    TopLevelDestination("health", "health", Icons.Default.Favorite),
    TopLevelDestination("finance", "finance", Icons.Default.AttachMoney),
    TopLevelDestination("profile", "profile", Icons.Default.Person)
  )

  val isTopLevelDestination = destinations.any { it.route == currentRoute }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Eco,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = when (currentRoute) {
                "home" -> LifeTrackStrings.get("app_name", lang)
                "routine" -> LifeTrackStrings.get("routine", lang)
                "health" -> LifeTrackStrings.get("health", lang)
                "finance" -> LifeTrackStrings.get("finance", lang)
                "profile" -> LifeTrackStrings.get("profile", lang)
                "meals" -> LifeTrackStrings.get("meals", lang)
                "water" -> LifeTrackStrings.get("water", lang)
                "workout" -> LifeTrackStrings.get("workout", lang)
                "sleep" -> LifeTrackStrings.get("sleep", lang)
                "shopping" -> LifeTrackStrings.get("shopping", lang)
                "tasks" -> LifeTrackStrings.get("tasks", lang)
                "calendar" -> LifeTrackStrings.get("calendar", lang)
                "analytics" -> LifeTrackStrings.get("analytics", lang)
                else -> LifeTrackStrings.get("app_name", lang)
              },
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
          }
        },
        navigationIcon = {
          if (!isTopLevelDestination) {
            IconButton(onClick = { navController.popBackStack() }) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back"
              )
            }
          }
        },
        actions = {
          // Language Switcher Pill
          Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.primaryContainer,
            modifier = Modifier
              .clip(RoundedCornerShape(16.dp))
              .clickable {
                val nextLang = if (lang == "en") "bn" else "en"
                viewModel.setLanguage(nextLang)
              }
              .testTag("lang_toggle_pill")
          ) {
            Text(
              text = if (lang == "en") "EN | বাংলা" else "বাংলা | EN",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.primary,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            )
          }

          // Analytics Button
          IconButton(onClick = { navController.navigate("analytics") }) {
            Icon(Icons.Default.Analytics, contentDescription = "Analytics", tint = MaterialTheme.colorScheme.primary)
          }

          // Calendar History Button
          IconButton(onClick = { navController.navigate("calendar") }) {
            Icon(Icons.Default.CalendarToday, contentDescription = "History Calendar")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.surface,
          titleContentColor = MaterialTheme.colorScheme.onSurface
        )
      )
    },
    bottomBar = {
      NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp
      ) {
        destinations.forEach { destination ->
          val isSelected = currentRoute == destination.route
          NavigationBarItem(
            selected = isSelected,
            onClick = {
              if (currentRoute != destination.route) {
                navController.navigate(destination.route) {
                  popUpTo(navController.graph.findStartDestination().id) {
                    saveState = true
                  }
                  launchSingleTop = true
                  restoreState = true
                }
              }
            },
            icon = {
              Icon(
                imageVector = destination.icon,
                contentDescription = LifeTrackStrings.get(destination.labelKey, lang),
                modifier = Modifier.size(24.dp)
              )
            },
            label = {
              Text(
                text = LifeTrackStrings.get(destination.labelKey, lang),
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
              )
            },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = MaterialTheme.colorScheme.primary,
              selectedTextColor = MaterialTheme.colorScheme.primary,
              indicatorColor = MaterialTheme.colorScheme.primaryContainer
            ),
            modifier = Modifier.testTag("nav_${destination.route}")
          )
        }
      }
    },
    floatingActionButton = {
      FloatingActionButton(
        onClick = { viewModel.openQuickAdd() },
        containerColor = MaterialTheme.colorScheme.primary,
        contentColor = Color.White,
        shape = CircleShape,
        modifier = Modifier.testTag("quick_add_fab")
      ) {
        Icon(Icons.Default.Add, contentDescription = "Quick Add", modifier = Modifier.size(28.dp))
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      NavHost(
        navController = navController,
        startDestination = "home"
      ) {
        // 5 Primary Destinations
        composable("home") {
          DashboardScreen(
            viewModel = viewModel,
            onNavigateToTab = { route -> navController.navigate(route) }
          )
        }
        composable("routine") {
          RoutineScreen(viewModel = viewModel)
        }
        composable("health") {
          HealthScreen(viewModel = viewModel)
        }
        composable("finance") {
          FinanceScreen(viewModel = viewModel)
        }
        composable("profile") {
          ProfileScreen(viewModel = viewModel, onSignOut = onSignOut)
        }

        // Dedicated Sub-Destinations
        composable("meals") {
          MealScreen(viewModel = viewModel)
        }
        composable("water") {
          WaterScreen(viewModel = viewModel)
        }
        composable("workout") {
          FitnessScreen(viewModel = viewModel)
        }
        composable("sleep") {
          SleepScreen(viewModel = viewModel)
        }
        composable("shopping") {
          ShoppingScreen(viewModel = viewModel)
        }
        composable("tasks") {
          TasksScreen(viewModel = viewModel)
        }
        composable("calendar") {
          CalendarHistoryScreen(viewModel = viewModel)
        }
        composable("analytics") {
          AnalyticsScreen(viewModel = viewModel)
        }
      }
    }
  }

  // Quick Action Modal
  if (showQuickAdd) {
    QuickAddBottomSheet(
      viewModel = viewModel,
      lang = lang,
      onDismiss = { viewModel.closeQuickAdd() }
    )
  }

  // Onboarding dialog
  if (showOnboarding) {
    OnboardingDialog(
      viewModel = viewModel,
      currentLang = lang,
      onDismiss = { hasCompletedOnboarding = true }
    )
  }
}
