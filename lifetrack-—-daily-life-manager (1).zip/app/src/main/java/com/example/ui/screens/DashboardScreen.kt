package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.LifeTrackViewModel
import com.example.util.LifeTrackStrings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
  viewModel: LifeTrackViewModel,
  onNavigateToTab: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val lang by viewModel.language.collectAsState()
  val userProfile by viewModel.userProfile.collectAsState()
  val routines by viewModel.routines.collectAsState()
  val routinePercent by viewModel.routineCompletionPercent.collectAsState()
  val totalWater by viewModel.totalWaterMl.collectAsState()
  val meals by viewModel.meals.collectAsState()
  val totalCalories by viewModel.totalCalories.collectAsState()
  val workouts by viewModel.workouts.collectAsState()
  val caloriesBurned by viewModel.totalCaloriesBurned.collectAsState()
  val latestSleep by viewModel.latestSleep.collectAsState()
  val monthlyIncome by viewModel.monthlyIncome.collectAsState()
  val monthlyExpense by viewModel.monthlyExpense.collectAsState()
  val tasks by viewModel.tasks.collectAsState()
  val todayWellness by viewModel.todayWellness.collectAsState()

  val waterTarget = userProfile?.waterTargetMl ?: 2500
  val waterFraction = (totalWater.toFloat() / waterTarget.toFloat()).coerceIn(0f, 1f)

  val stepsGoal = userProfile?.dailyStepTarget ?: 8000
  val stepsLogged = todayWellness?.steps ?: 0
  val stepsFraction = (stepsLogged.toFloat() / stepsGoal.toFloat()).coerceIn(0f, 1f)

  val greetingKey = when (java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)) {
    in 4..11 -> "good_morning"
    in 12..16 -> "good_afternoon"
    else -> "good_evening"
  }

  val todayDisplayDate = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date())

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // 1. Header greeting
    item {
      Spacer(modifier = Modifier.height(8.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "${LifeTrackStrings.get(greetingKey, lang)}, ${userProfile?.name ?: "Friend"} 👋",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onBackground
          )
          Text(
            text = todayDisplayDate,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }

    // 2. Motivational Message Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
        )
      ) {
        Row(
          modifier = Modifier.padding(16.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(42.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.Lightbulb, contentDescription = null, tint = Color.White)
          }
          Spacer(modifier = Modifier.width(14.dp))
          Text(
            text = LifeTrackStrings.get("quote_1", lang),
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
            color = MaterialTheme.colorScheme.onPrimaryContainer
          )
        }
      }
    }

    // 3. Daily Routine & Water Hero Cards
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        // Routine Completion Card
        Card(
          modifier = Modifier
            .weight(1f)
            .clickable { onNavigateToTab("routine") }
            .testTag("home_routine_card"),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = LifeTrackStrings.get("routine", lang),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
              )
              Icon(Icons.Default.Repeat, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            }
            Spacer(modifier = Modifier.height(14.dp))
            Box(
              modifier = Modifier
                .size(72.dp)
                .align(Alignment.CenterHorizontally),
              contentAlignment = Alignment.Center
            ) {
              CircularProgressIndicator(
                progress = { routinePercent / 100f },
                modifier = Modifier.fillMaxSize(),
                strokeWidth = 7.dp,
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
              )
              Text(
                text = "$routinePercent%",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary
              )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = "${routines.count { it.isCompleted }}/${routines.size} ${LifeTrackStrings.get("completed", lang).lowercase()}",
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.align(Alignment.CenterHorizontally)
            )
          }
        }

        // Hydration Progress Card
        Card(
          modifier = Modifier
            .weight(1f)
            .clickable { onNavigateToTab("water") }
            .testTag("home_water_card"),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = LifeTrackStrings.get("water", lang),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
              )
              Icon(Icons.Default.WaterDrop, contentDescription = null, tint = Color(0xFF0284C7))
            }
            Spacer(modifier = Modifier.height(14.dp))
            Box(
              modifier = Modifier
                .size(72.dp)
                .align(Alignment.CenterHorizontally),
              contentAlignment = Alignment.Center
            ) {
              CircularProgressIndicator(
                progress = { waterFraction },
                modifier = Modifier.fillMaxSize(),
                strokeWidth = 7.dp,
                color = Color(0xFF0284C7),
                trackColor = MaterialTheme.colorScheme.surfaceVariant
              )
              Text(
                text = "${(waterFraction * 100).toInt()}%",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = Color(0xFF0284C7)
              )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = "$totalWater / $waterTarget ml",
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.align(Alignment.CenterHorizontally)
            )
          }
        }
      }
    }

    // 4. Meals Summary
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onNavigateToTab("meals") },
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFFEF3C7)),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.Restaurant, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(20.dp))
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = LifeTrackStrings.get("meals", lang),
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                  text = "${meals.size} logged today",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
            Text(
              text = "${totalCalories.toInt()} kcal",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = Color(0xFFD97706)
            )
          }

          if (meals.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              meals.take(3).forEach { meal ->
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                  modifier = Modifier.padding(vertical = 2.dp)
                ) {
                  Text(
                    text = "${meal.foodName} (${meal.calories.toInt()}k)",
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                  )
                }
              }
            }
          }
        }
      }
    }

    // 5. Workouts & Sleep Row
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        // Workout Card
        Card(
          modifier = Modifier
            .weight(1f)
            .clickable { onNavigateToTab("workout") },
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Color(0xFFD1FAE5)),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.FitnessCenter, contentDescription = null, tint = Color(0xFF059669), modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = LifeTrackStrings.get("workout", lang),
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
            Text(
              text = if (workouts.isEmpty()) "Rest day" else "${workouts.size} exercises",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (caloriesBurned > 0) {
              Text(
                text = "${caloriesBurned.toInt()} kcal burned",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                color = Color(0xFF059669)
              )
            }
          }
        }

        // Sleep Card
        Card(
          modifier = Modifier
            .weight(1f)
            .clickable { onNavigateToTab("sleep") },
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Color(0xFFEDE9FE)),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Bedtime, contentDescription = null, tint = Color(0xFF7C3AED), modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = LifeTrackStrings.get("sleep", lang),
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
            val sleepHours = latestSleep?.let { it.durationMinutes / 60 } ?: 8
            val sleepMins = latestSleep?.let { it.durationMinutes % 60 } ?: 0
            Text(
              text = "${sleepHours}h ${sleepMins}m",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = Color(0xFF7C3AED)
            )
            Text(
              text = "Rating: ${latestSleep?.qualityRating ?: 4}/5 ★",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    }

    // 6. Finances Snapshot
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onNavigateToTab("finance") },
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFFEE2E2)),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.AttachMoney, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(20.dp))
              }
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = LifeTrackStrings.get("finance", lang),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
              )
            }
            Text(
              text = "Net: ${(monthlyIncome - monthlyExpense).toInt()} ৳",
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
              color = if (monthlyIncome >= monthlyExpense) MaterialTheme.colorScheme.primary else Color(0xFFDC2626)
            )
          }
          Spacer(modifier = Modifier.height(12.dp))
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text = "Income: ${monthlyIncome.toInt()} ৳", style = MaterialTheme.typography.bodySmall, color = Color(0xFF059669))
            Text(text = "Spent: ${monthlyExpense.toInt()} ৳", style = MaterialTheme.typography.bodySmall, color = Color(0xFFDC2626))
          }
        }
      }
    }

    // 7. Today's Pending Tasks
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onNavigateToTab("tasks") },
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = LifeTrackStrings.get("today_tasks", lang),
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Icon(Icons.AutoMirrored.Filled.Assignment, contentDescription = null, tint = Color(0xFF7C3AED))
          }
          Spacer(modifier = Modifier.height(8.dp))
          val pendingTasks = tasks.filter { !it.isCompleted }
          if (pendingTasks.isEmpty()) {
            Text(
              text = "All tasks completed! Great job 🎉",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          } else {
            pendingTasks.take(3).forEach { task ->
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(if (task.priority == "high") Color.Red else Color.Gray)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = task.title,
                  style = MaterialTheme.typography.bodyMedium,
                  modifier = Modifier.weight(1f)
                )
              }
            }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(64.dp))
    }
  }
}
