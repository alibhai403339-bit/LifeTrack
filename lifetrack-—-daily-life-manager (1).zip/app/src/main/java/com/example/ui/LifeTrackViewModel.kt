package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.FinanceTransaction
import com.example.data.model.MealEntry
import com.example.data.model.RoutineItem
import com.example.data.model.ShoppingItem
import com.example.data.model.SleepLog
import com.example.data.model.TaskItem
import com.example.data.model.UserProfile
import com.example.data.model.WaterLog
import com.example.data.model.WellnessLog
import com.example.data.model.WorkoutLog
import com.example.data.repository.LifeTrackRepository
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.ExperimentalCoroutinesApi

@OptIn(ExperimentalCoroutinesApi::class)
class LifeTrackViewModel(application: Application) : AndroidViewModel(application) {

  private val repository = LifeTrackRepository(application.applicationContext)
  private val auth = Firebase.auth

  private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
  private val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())

  // Current selected date (YYYY-MM-DD)
  private val _selectedDate = MutableStateFlow(dateFormat.format(Date()))
  val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

  // Language & Theme state
  private val _language = MutableStateFlow("en") // "en" or "bn"
  val language: StateFlow<String> = _language.asStateFlow()

  private val _themeMode = MutableStateFlow("light") // "light", "dark", "system"
  val themeMode: StateFlow<String> = _themeMode.asStateFlow()

  // User Profile
  val userProfile: StateFlow<UserProfile?> = repository.observeProfile()
    .catch { emit(null) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

  // Routines
  val routines: StateFlow<List<RoutineItem>> = repository.observeRoutines()
    .catch { emit(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  // Routine Completion %
  val routineCompletionPercent: StateFlow<Int> = routines.combine(_selectedDate) { list, _ ->
    if (list.isEmpty()) 0
    else ((list.count { it.isCompleted }.toFloat() / list.size.toFloat()) * 100).toInt()
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), 0)

  // Meals for selected date
  val meals: StateFlow<List<MealEntry>> = _selectedDate.flatMapLatest { date ->
    repository.observeMeals(date).catch { emit(emptyList()) }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  // Total nutrition for selected date
  val totalCalories: StateFlow<Double> = meals.combine(_selectedDate) { list, _ ->
    list.sumOf { it.calories }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), 0.0)

  // Water intake for selected date
  val waterLogs: StateFlow<List<WaterLog>> = _selectedDate.flatMapLatest { date ->
    repository.observeWaterLogs(date).catch { emit(emptyList()) }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  val totalWaterMl: StateFlow<Int> = waterLogs.combine(_selectedDate) { list, _ ->
    list.sumOf { it.amountMl }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), 0)

  // Workouts for selected date
  val workouts: StateFlow<List<WorkoutLog>> = _selectedDate.flatMapLatest { date ->
    repository.observeWorkouts(date).catch { emit(emptyList()) }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  val totalCaloriesBurned: StateFlow<Double> = workouts.combine(_selectedDate) { list, _ ->
    list.sumOf { it.caloriesBurned }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), 0.0)

  // Sleep Logs
  val sleepLogs: StateFlow<List<SleepLog>> = repository.observeSleepLogs()
    .catch { emit(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  // Latest Sleep Log
  val latestSleep: StateFlow<SleepLog?> = sleepLogs.combine(_selectedDate) { logs, _ ->
    logs.maxByOrNull { it.date }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

  // Finance Transactions
  val transactions: StateFlow<List<FinanceTransaction>> = repository.observeTransactions()
    .catch { emit(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  val monthlyIncome: StateFlow<Double> = transactions.combine(_selectedDate) { list, _ ->
    list.filter { it.type == "income" }.sumOf { it.amount }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), 0.0)

  val monthlyExpense: StateFlow<Double> = transactions.combine(_selectedDate) { list, _ ->
    list.filter { it.type == "expense" }.sumOf { it.amount }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), 0.0)

  // Shopping Items
  val shoppingItems: StateFlow<List<ShoppingItem>> = repository.observeShoppingItems()
    .catch { emit(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  // Tasks
  val tasks: StateFlow<List<TaskItem>> = repository.observeTasks()
    .catch { emit(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  // Wellness Logs
  val wellnessLogs: StateFlow<List<WellnessLog>> = repository.observeWellnessLogs()
    .catch { emit(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  val todayWellness: StateFlow<WellnessLog?> = wellnessLogs.combine(_selectedDate) { logs, date ->
    logs.find { it.date == date }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

  // Workout Timer State
  private val _workoutTimerSeconds = MutableStateFlow(0)
  val workoutTimerSeconds: StateFlow<Int> = _workoutTimerSeconds.asStateFlow()

  private val _isWorkoutTimerRunning = MutableStateFlow(false)
  val isWorkoutTimerRunning: StateFlow<Boolean> = _isWorkoutTimerRunning.asStateFlow()
  private var workoutTimerJob: Job? = null

  // Rest Timer State
  private val _restTimerSeconds = MutableStateFlow(60)
  val restTimerSeconds: StateFlow<Int> = _restTimerSeconds.asStateFlow()

  private val _isRestTimerRunning = MutableStateFlow(false)
  val isRestTimerRunning: StateFlow<Boolean> = _isRestTimerRunning.asStateFlow()
  private var restTimerJob: Job? = null

  // Quick Action Modal Visibility
  private val _showQuickAddModal = MutableStateFlow(false)
  val showQuickAddModal: StateFlow<Boolean> = _showQuickAddModal.asStateFlow()

  init {
    viewModelScope.launch {
      try {
        userProfile.collect { profile ->
          if (profile != null) {
            _language.value = profile.language
            _themeMode.value = profile.themeMode
          }
        }
      } catch (e: Exception) {
        // Safe catch - prevent coroutine failure from bubbling up
      }
    }
  }

  fun setLanguage(lang: String) {
    _language.value = lang
    val current = userProfile.value
    if (current != null) {
      viewModelScope.launch {
        repository.saveProfile(current.copy(language = lang))
      }
    }
  }

  fun setThemeMode(theme: String) {
    _themeMode.value = theme
    val current = userProfile.value
    if (current != null) {
      viewModelScope.launch {
        repository.saveProfile(current.copy(themeMode = theme))
      }
    }
  }

  fun setSelectedDate(date: String) {
    _selectedDate.value = date
  }

  fun openQuickAdd() {
    _showQuickAddModal.value = true
  }

  fun closeQuickAdd() {
    _showQuickAddModal.value = false
  }

  // --- Profile Operations ---
  fun saveUserProfile(
    name: String,
    waterTarget: Int,
    sleepTarget: Double,
    stepTarget: Int,
    monthlyBudget: Double,
    heightCm: Double,
    weightKg: Double,
    wakeUpTime: String = "06:30 AM",
    bedTime: String = "10:30 PM"
  ) {
    viewModelScope.launch {
      val existing = userProfile.value
      val profile = UserProfile(
        userId = repository.requireUserId(),
        name = name,
        email = auth.currentUser?.email ?: "",
        language = _language.value,
        themeMode = _themeMode.value,
        wakeUpTime = wakeUpTime,
        bedTime = bedTime,
        waterTargetMl = waterTarget,
        sleepTargetHours = sleepTarget,
        dailyStepTarget = stepTarget,
        monthlyBudget = monthlyBudget,
        heightCm = heightCm,
        weightKg = weightKg,
        createdAt = existing?.createdAt
      )
      repository.saveProfile(profile)
    }
  }

  // --- Water Operations ---
  fun addWater(amountMl: Int) {
    viewModelScope.launch {
      val nowTime = timeFormat.format(Date())
      repository.addWaterLog(amountMl, _selectedDate.value, nowTime)
    }
  }

  fun undoLastWater() {
    val logs = waterLogs.value
    if (logs.isNotEmpty()) {
      val last = logs.last()
      viewModelScope.launch {
        repository.deleteWaterLog(last.id)
      }
    }
  }

  // --- Meal Operations ---
  fun addMeal(
    type: String,
    foodName: String,
    quantity: String,
    calories: Double,
    protein: Double,
    carbs: Double,
    fat: Double
  ) {
    viewModelScope.launch {
      val meal = MealEntry(
        userId = repository.requireUserId(),
        mealType = type,
        foodName = foodName,
        quantity = quantity,
        mealTime = timeFormat.format(Date()),
        calories = calories,
        proteinG = protein,
        carbsG = carbs,
        fatG = fat,
        date = _selectedDate.value
      )
      repository.addMeal(meal)
    }
  }

  fun deleteMeal(mealId: String) {
    viewModelScope.launch {
      repository.deleteMeal(mealId)
    }
  }

  // --- Routine Operations ---
  fun addRoutine(title: String, time: String, icon: String, category: String) {
    viewModelScope.launch {
      repository.addRoutine(title, time, icon, category)
    }
  }

  fun toggleRoutine(routineId: String, currentCompleted: Boolean) {
    viewModelScope.launch {
      repository.toggleRoutine(routineId, !currentCompleted)
    }
  }

  fun deleteRoutine(routineId: String) {
    viewModelScope.launch {
      repository.deleteRoutine(routineId)
    }
  }

  // --- Workout Operations ---
  fun addWorkout(
    name: String,
    category: String,
    sets: Int,
    reps: Int,
    weightKg: Double,
    durationMinutes: Int,
    caloriesBurned: Double
  ) {
    viewModelScope.launch {
      val workout = WorkoutLog(
        userId = repository.requireUserId(),
        exerciseName = name,
        category = category,
        sets = sets,
        reps = reps,
        weightKg = weightKg,
        durationMinutes = durationMinutes,
        caloriesBurned = caloriesBurned,
        date = _selectedDate.value
      )
      repository.addWorkout(workout)
    }
  }

  fun deleteWorkout(workoutId: String) {
    viewModelScope.launch {
      repository.deleteWorkout(workoutId)
    }
  }

  // --- Workout Timer ---
  fun toggleWorkoutTimer() {
    if (_isWorkoutTimerRunning.value) {
      workoutTimerJob?.cancel()
      _isWorkoutTimerRunning.value = false
    } else {
      _isWorkoutTimerRunning.value = true
      workoutTimerJob = viewModelScope.launch {
        while (_isWorkoutTimerRunning.value) {
          delay(1000L)
          _workoutTimerSeconds.value += 1
        }
      }
    }
  }

  fun resetWorkoutTimer() {
    workoutTimerJob?.cancel()
    _isWorkoutTimerRunning.value = false
    _workoutTimerSeconds.value = 0
  }

  // --- Rest Timer ---
  fun startRestTimer(seconds: Int) {
    restTimerJob?.cancel()
    _restTimerSeconds.value = seconds
    _isRestTimerRunning.value = true
    restTimerJob = viewModelScope.launch {
      while (_restTimerSeconds.value > 0 && _isRestTimerRunning.value) {
        delay(1000L)
        _restTimerSeconds.value -= 1
      }
      _isRestTimerRunning.value = false
    }
  }

  fun stopRestTimer() {
    restTimerJob?.cancel()
    _isRestTimerRunning.value = false
  }

  // --- Sleep Operations ---
  fun addSleep(sleepTime: String, wakeTime: String, durationMinutes: Int, quality: Int, notes: String) {
    viewModelScope.launch {
      val log = SleepLog(
        userId = repository.requireUserId(),
        sleepTime = sleepTime,
        wakeTime = wakeTime,
        durationMinutes = durationMinutes,
        qualityRating = quality,
        date = _selectedDate.value,
        notes = notes
      )
      repository.addSleepLog(log)
    }
  }

  // --- Finance Operations ---
  fun addTransaction(
    type: String,
    category: String,
    amount: Double,
    notes: String,
    paymentMethod: String
  ) {
    viewModelScope.launch {
      val tx = FinanceTransaction(
        userId = repository.requireUserId(),
        type = type,
        category = category,
        amount = amount,
        date = _selectedDate.value,
        notes = notes,
        paymentMethod = paymentMethod
      )
      repository.addTransaction(tx)
    }
  }

  fun deleteTransaction(txId: String) {
    viewModelScope.launch {
      repository.deleteTransaction(txId)
    }
  }

  // --- Shopping Operations ---
  fun addShoppingItem(
    name: String,
    category: String,
    quantity: String,
    estimatedPrice: Double
  ) {
    viewModelScope.launch {
      val item = ShoppingItem(
        userId = repository.requireUserId(),
        name = name,
        category = category,
        quantity = quantity,
        estimatedPrice = estimatedPrice,
        actualPrice = 0.0,
        isPurchased = false
      )
      repository.addShoppingItem(item)
    }
  }

  fun toggleShoppingItem(itemId: String, isPurchased: Boolean, actualPrice: Double? = null) {
    viewModelScope.launch {
      repository.toggleShoppingItem(itemId, isPurchased, actualPrice)
    }
  }

  fun deleteShoppingItem(itemId: String) {
    viewModelScope.launch {
      repository.deleteShoppingItem(itemId)
    }
  }

  fun clearPurchasedShopping() {
    viewModelScope.launch {
      shoppingItems.value.filter { it.isPurchased }.forEach { item ->
        repository.deleteShoppingItem(item.id)
      }
    }
  }

  // --- Task Operations ---
  fun addTask(title: String, priority: String, dueDate: String, dueTime: String, category: String) {
    viewModelScope.launch {
      val task = TaskItem(
        userId = repository.requireUserId(),
        title = title,
        priority = priority,
        dueDate = dueDate,
        dueTime = dueTime,
        category = category,
        isCompleted = false
      )
      repository.addTask(task)
    }
  }

  fun toggleTask(taskId: String, currentCompleted: Boolean) {
    viewModelScope.launch {
      repository.toggleTask(taskId, !currentCompleted)
    }
  }

  fun deleteTask(taskId: String) {
    viewModelScope.launch {
      repository.deleteTask(taskId)
    }
  }

  // --- Wellness Operations ---
  fun saveDailyWellness(weightKg: Double, steps: Int, mood: String, energyLevel: Int, notes: String) {
    viewModelScope.launch {
      val current = todayWellness.value
      val log = WellnessLog(
        id = current?.id ?: "",
        userId = repository.requireUserId(),
        date = _selectedDate.value,
        weightKg = weightKg,
        steps = steps,
        mood = mood,
        energyLevel = energyLevel,
        notes = notes,
        createdAt = current?.createdAt
      )
      repository.saveWellnessLog(log)
    }
  }

  // Helper calculations
  fun calculateBmi(weightKg: Double, heightCm: Double): Pair<Double, String> {
    if (heightCm <= 0 || weightKg <= 0) return Pair(0.0, "N/A")
    val heightM = heightCm / 100.0
    val bmi = weightKg / (heightM * heightM)
    val category = when {
      bmi < 18.5 -> "Underweight"
      bmi < 25.0 -> "Normal weight"
      bmi < 30.0 -> "Overweight"
      else -> "Obese"
    }
    return Pair(Math.round(bmi * 10.0) / 10.0, category)
  }
}
